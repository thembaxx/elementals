import Link from 'next/link';

export default function NotFound() {
  return (
    <main className="mx-auto flex min-h-dvh max-w-md flex-col items-center justify-center gap-4 px-6 text-center">
      <p className="num m-0 text-6xl font-bold opacity-30">404</p>
      <h1 className="m-0 text-2xl font-extrabold">That element isn’t on the table</h1>
      <p className="m-0 text-mut">The page you’re looking for doesn’t exist.</p>
      <Link href="/" className="chip no-underline">
        Back to the periodic table
      </Link>
    </main>
  );
}
