import ElementsApp from '@/components/ElementsApp';

export default function HomePage() {
  return (
    <>
      <ElementsApp />
      <noscript>
        <p style={{ position: 'fixed', inset: 'auto 0 0 0', margin: 0, padding: 16, textAlign: 'center' }}>
          Elements needs JavaScript for its interactive 3D table. Every element also has its own page at /element/&lt;symbol&gt;.
        </p>
      </noscript>
    </>
  );
}
