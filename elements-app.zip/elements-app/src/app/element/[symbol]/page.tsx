import type { Metadata } from 'next';
import Link from 'next/link';
import { notFound } from 'next/navigation';
import { ELEMENTS } from '@/data/elements';
import { ConfigText } from '@/components/ConfigText';
import { ShellDiagram } from '@/components/ShellDiagram';
import { CATEGORY_META, PHASE_LABEL, approxNeutrons, formatMass, getBySlug, getElement, groupLabel } from '@/lib/elements';

export const dynamicParams = false;

interface PageProps {
  params: Promise<{ symbol: string }>;
}

export function generateStaticParams(): { symbol: string }[] {
  return ELEMENTS.map((e) => ({ symbol: e.slug }));
}

export async function generateMetadata({ params }: PageProps): Promise<Metadata> {
  const { symbol } = await params;
  const e = getBySlug(symbol);
  if (!e) return { title: 'Element not found' };
  const title = `${e.name} (${e.symbol}), element ${e.z}`;
  const description = `${e.name} is element ${e.z} (${CATEGORY_META[e.category].label.toLowerCase()}). ${e.fact}`;
  return {
    title,
    description,
    alternates: { canonical: `/element/${e.slug}` },
    openGraph: { type: 'article', title, description, url: `/element/${e.slug}` },
  };
}

export default async function ElementPage({ params }: PageProps) {
  const { symbol } = await params;
  const e = getBySlug(symbol);
  if (!e) notFound();

  const color = CATEGORY_META[e.category].color;
  const prev = e.z > 1 ? getElement(e.z - 1) : null;
  const next = e.z < ELEMENTS.length ? getElement(e.z + 1) : null;
  const facts: readonly { label: string; value: string }[] = [
    { label: 'Atomic number', value: String(e.z) },
    { label: 'Atomic mass', value: formatMass(e) },
    { label: 'Category', value: CATEGORY_META[e.category].label },
    { label: 'Phase at 0 °C', value: PHASE_LABEL[e.phase] },
    { label: 'Period', value: String(e.period) },
    { label: 'Group', value: groupLabel(e) },
    { label: 'Block', value: `${e.block}-block` },
    { label: 'Electronegativity', value: e.en === null ? 'Not defined' : e.en.toFixed(2) },
    { label: 'Discovered', value: e.discovered },
    { label: 'Neutrons (approx.)', value: String(approxNeutrons(e)) },
  ];

  return (
    <main className="mx-auto min-h-dvh w-full max-w-2xl px-5 pb-16 pt-[max(24px,env(safe-area-inset-top))]">
      <nav className="flex items-center justify-between text-sm font-bold">
        <Link href={`/?e=${e.symbol}`} className="chip no-underline">
          ← Explore in 3D
        </Link>
        <span className="num text-mut">
          {e.z} / {ELEMENTS.length}
        </span>
      </nav>

      <header className="mt-8 flex items-center gap-5">
        <div
          className="flex h-28 w-28 flex-none items-center justify-center rounded-full text-5xl font-extrabold"
          style={{
            background: `radial-gradient(circle at 35% 28%, #ffffff99, ${color} 55%, #0a0e2f)`,
            color: '#fff',
            textShadow: '0 4px 18px rgba(5,10,40,.45)',
          }}
          aria-hidden="true"
        >
          {e.symbol}
        </div>
        <div>
          <h1 className="m-0 text-4xl font-extrabold leading-tight">{e.name}</h1>
          <p className="m-0 mt-1 text-sm font-bold text-mut">{CATEGORY_META[e.category].label}</p>
        </div>
      </header>

      <p className="mt-6 text-lg font-semibold leading-snug">{e.fact}</p>

      <section aria-label="Electron structure" className="mt-6 rounded-3xl bg-chip p-5 text-center">
        <ShellDiagram shells={e.shells} color={color} label={`Electron shells of ${e.name}: ${e.shells.join(', ')}`} size={220} />
        <p className="num mb-0 mt-2 text-sm text-mut">Shells {e.shells.join(' · ')}</p>
        <p className="mb-0 mt-1 text-sm text-mut">
          <ConfigText config={e.config} />
          {e.z >= 104 ? ' (predicted)' : ''}
        </p>
      </section>

      <dl className="m-0 mt-6 grid grid-cols-2 gap-3 sm:grid-cols-3">
        {facts.map((f) => (
          <div key={f.label} className="rounded-2xl bg-chip p-3">
            <dt className="text-xs font-bold text-mut">{f.label}</dt>
            <dd className="num m-0 mt-1 text-base font-bold">{f.value}</dd>
          </div>
        ))}
      </dl>

      <nav aria-label="Neighboring elements" className="mt-8 flex justify-between gap-3">
        {prev ? (
          <Link href={`/element/${prev.slug}`} className="chip no-underline" prefetch={false}>
            ← {prev.name}
          </Link>
        ) : (
          <span />
        )}
        {next ? (
          <Link href={`/element/${next.slug}`} className="chip no-underline" prefetch={false}>
            {next.name} →
          </Link>
        ) : (
          <span />
        )}
      </nav>
    </main>
  );
}
