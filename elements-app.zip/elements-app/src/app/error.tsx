'use client';

import { useEffect } from 'react';

export default function ErrorPage({ error, reset }: { error: Error & { digest?: string }; reset: () => void }) {
  useEffect(() => {
    console.error(error);
  }, [error]);

  return (
    <main className="mx-auto flex min-h-dvh max-w-md flex-col items-center justify-center gap-4 px-6 text-center">
      <h1 className="m-0 text-2xl font-extrabold">Something went wrong</h1>
      <p className="m-0 text-mut">An unexpected error interrupted the experiment. You can try again.</p>
      <button type="button" className="chip chip-btn" onClick={() => reset()}>
        Try again
      </button>
    </main>
  );
}
