import type { MetadataRoute } from 'next';
import { ELEMENTS } from '@/data/elements';
import { SITE_URL } from '@/lib/site';

export default function sitemap(): MetadataRoute.Sitemap {
  return [
    { url: `${SITE_URL}/`, changeFrequency: 'monthly', priority: 1 },
    ...ELEMENTS.map((e) => ({ url: `${SITE_URL}/element/${e.slug}`, changeFrequency: 'yearly' as const, priority: 0.6 })),
  ];
}
