import type { Metadata, Viewport } from 'next';
import { JetBrains_Mono, Nunito } from 'next/font/google';
import type { ReactNode } from 'react';
import './globals.css';
import { SITE_DESCRIPTION, SITE_NAME, SITE_URL } from '@/lib/site';

const nunito = Nunito({ subsets: ['latin'], variable: '--font-nunito', display: 'swap' });
const jetbrainsMono = JetBrains_Mono({ subsets: ['latin'], variable: '--font-jb', display: 'swap' });

export const metadata: Metadata = {
  metadataBase: new URL(SITE_URL),
  title: { default: `${SITE_NAME}: an interactive periodic table`, template: `%s · ${SITE_NAME}` },
  description: SITE_DESCRIPTION,
  applicationName: SITE_NAME,
  openGraph: {
    type: 'website',
    siteName: SITE_NAME,
    title: `${SITE_NAME}: an interactive periodic table`,
    description: SITE_DESCRIPTION,
    url: '/',
  },
  twitter: { card: 'summary', title: `${SITE_NAME}: an interactive periodic table`, description: SITE_DESCRIPTION },
};

export const viewport: Viewport = {
  width: 'device-width',
  initialScale: 1,
  viewportFit: 'cover',
  themeColor: [
    { media: '(prefers-color-scheme: dark)', color: '#0A0E2F' },
    { media: '(prefers-color-scheme: light)', color: '#CFE6FF' },
  ],
};

// Runs before first paint so a saved theme never flashes the wrong colors.
const THEME_SCRIPT = `(function(){try{var t=localStorage.getItem('elements:theme');if(t==='midnight'||t==='dusk'||t==='day'){document.documentElement.setAttribute('data-theme',t)}}catch(e){}})();`;

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en" className={`${nunito.variable} ${jetbrainsMono.variable}`} suppressHydrationWarning>
      <head>
        <script dangerouslySetInnerHTML={{ __html: THEME_SCRIPT }} />
      </head>
      <body>{children}</body>
    </html>
  );
}
