'use client';

import { useEffect, useRef } from 'react';
import type { KeyboardEvent, ReactNode } from 'react';
import { CloseIcon } from '@/components/Icons';

interface SheetProps {
  open: boolean;
  label: string;
  onClose: () => void;
  children: ReactNode;
  tall?: boolean;
}

/** Bottom sheet: modal semantics, focus moves in on open and returns on close, Escape closes. */
export function Sheet({ open, label, onClose, children, tall = false }: SheetProps) {
  const ref = useRef<HTMLElement>(null);
  const returnTo = useRef<Element | null>(null);

  useEffect(() => {
    if (open) {
      returnTo.current = document.activeElement;
      const id = window.setTimeout(() => ref.current?.focus({ preventScroll: true }), 60);
      return () => window.clearTimeout(id);
    }
    const previous = returnTo.current;
    returnTo.current = null;
    if (previous instanceof HTMLElement) previous.focus({ preventScroll: true });
    return undefined;
  }, [open]);

  const onKeyDown = (e: KeyboardEvent<HTMLElement>): void => {
    if (e.key === 'Escape') {
      e.stopPropagation();
      onClose();
    }
  };

  return (
    <section
      ref={ref}
      role="dialog"
      aria-modal="true"
      aria-label={label}
      aria-hidden={!open}
      inert={!open}
      tabIndex={-1}
      onKeyDown={onKeyDown}
      className={`sheet ${open ? 'sheet-open' : ''} ${tall ? 'tall' : ''}`}
    >
      {children}
    </section>
  );
}

interface SheetHeaderProps {
  title: string;
  onClose: () => void;
  left?: ReactNode;
}

export function SheetHeader({ title, onClose, left }: SheetHeaderProps) {
  return (
    <div className="sheet-head">
      <div className="flex min-w-[44px] items-center">{left}</div>
      <h2>{title}</h2>
      <button type="button" className="round-btn flat" onClick={onClose} aria-label={`Close ${title}`}>
        <CloseIcon />
      </button>
    </div>
  );
}
