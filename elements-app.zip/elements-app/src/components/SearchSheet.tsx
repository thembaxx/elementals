'use client';

import { useEffect, useMemo, useRef, useState } from 'react';
import type { CSSProperties, KeyboardEvent } from 'react';
import { Sheet, SheetHeader } from '@/components/Sheet';
import { CATEGORY_META, CATEGORY_ORDER, PHASE_LABEL, searchElements } from '@/lib/elements';

interface SearchSheetProps {
  open: boolean;
  onPick: (z: number) => void;
  onClose: () => void;
}

export function SearchSheet({ open, onPick, onClose }: SearchSheetProps) {
  const [query, setQuery] = useState('');
  const [active, setActive] = useState(0);
  const inputRef = useRef<HTMLInputElement>(null);
  const results = useMemo(() => searchElements(query), [query]);

  useEffect(() => {
    if (!open) return;
    setQuery('');
    setActive(0);
    const id = window.setTimeout(() => inputRef.current?.focus(), 150);
    return () => window.clearTimeout(id);
  }, [open]);

  useEffect(() => {
    document.getElementById(`search-result-${active}`)?.scrollIntoView({ block: 'nearest' });
  }, [active]);

  const onKeyDown = (e: KeyboardEvent<HTMLInputElement>): void => {
    if (e.key === 'ArrowDown') {
      e.preventDefault();
      setActive((i) => Math.min(i + 1, Math.max(results.length - 1, 0)));
    } else if (e.key === 'ArrowUp') {
      e.preventDefault();
      setActive((i) => Math.max(i - 1, 0));
    } else if (e.key === 'Enter') {
      const hit = results[active];
      if (hit) onPick(hit.z);
    }
  };

  return (
    <Sheet open={open} label="Search elements" onClose={onClose} tall>
      <SheetHeader title="Search" onClose={onClose} />
      <div className="px-3.5 pb-2 pt-3">
        <input
          ref={inputRef}
          type="search"
          value={query}
          onChange={(e) => {
            setQuery(e.target.value);
            setActive(0);
          }}
          onKeyDown={onKeyDown}
          placeholder="Name, symbol, number or type"
          aria-label="Search elements"
          aria-controls="search-results"
          autoComplete="off"
          autoCorrect="off"
          spellCheck={false}
          className="h-12 w-full rounded-full border-0 bg-chip px-5 text-[16px] font-semibold text-ink placeholder:text-mut"
        />
      </div>
      <div className="sheet-scroll px-3.5">
        {query.trim() === '' ? (
          <div>
            <p className="mb-2 mt-1 text-xs font-bold text-mut">Browse by type</p>
            <div className="flex flex-wrap gap-2">
              {CATEGORY_ORDER.map((c) => (
                <button key={c} type="button" className="chip chip-btn" onClick={() => setQuery(CATEGORY_META[c].label)}>
                  <span className="inline-block h-2.5 w-2.5 rounded-full" style={{ background: CATEGORY_META[c].color }} />
                  {CATEGORY_META[c].label}
                </button>
              ))}
            </div>
          </div>
        ) : results.length === 0 ? (
          <p className="mt-6 text-center text-[15px] font-semibold text-mut" role="status">
            No element matches “{query.trim()}”.
          </p>
        ) : (
          <ul id="search-results" role="listbox" aria-label="Results" className="m-0 list-none p-0">
            {results.map((e, i) => (
              <li
                key={e.z}
                id={`search-result-${i}`}
                role="option"
                aria-selected={i === active}
                className={`flex cursor-pointer items-center gap-3 rounded-2xl px-2 py-2 ${i === active ? 'bg-sel' : ''}`}
                onMouseEnter={() => setActive(i)}
                onClick={() => onPick(e.z)}
              >
                <span
                  className="flex h-11 w-11 flex-none items-center justify-center rounded-full text-[15px] font-extrabold"
                  style={{ '--c': CATEGORY_META[e.category].color, background: 'var(--c)', color: '#0b1031' } as CSSProperties}
                >
                  {e.symbol}
                </span>
                <span className="min-w-0 flex-1">
                  <span className="block truncate text-[15px] font-bold">{e.name}</span>
                  <span className="block truncate text-[12px] font-semibold text-mut">
                    {CATEGORY_META[e.category].label} · {PHASE_LABEL[e.phase]}
                  </span>
                </span>
                <span className="num text-[13px] text-mut">{e.z}</span>
              </li>
            ))}
          </ul>
        )}
      </div>
    </Sheet>
  );
}
