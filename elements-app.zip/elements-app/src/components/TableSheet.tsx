'use client';

import { useEffect, useRef, useState } from 'react';
import type { CSSProperties, PointerEvent as ReactPointerEvent } from 'react';
import { ELEMENTS } from '@/data/elements';
import { MinusIcon, PlusIcon } from '@/components/Icons';
import { Sheet, SheetHeader } from '@/components/Sheet';
import { ELEMENT_COUNT, LAYERS, LAYER_LEGEND, layerColor } from '@/lib/elements';
import type { Layer } from '@/lib/elements';

interface TableSheetProps {
  open: boolean;
  selected: number;
  found: ReadonlySet<number>;
  layer: Layer;
  onPick: (z: number, bubble: HTMLElement | null) => void;
  onLayer: (layer: Layer) => void;
  onQuiz: () => void;
  onClose: () => void;
}

const MIN_SIZE = 30;
const MAX_SIZE = 78;
const clampSize = (v: number): number => Math.max(MIN_SIZE, Math.min(MAX_SIZE, v));

export function TableSheet({ open, selected, found, layer, onPick, onLayer, onQuiz, onClose }: TableSheetProps) {
  const [size, setSize] = useState(56);
  const gridRef = useRef<HTMLDivElement>(null);
  const pointers = useRef(new Map<number, { x: number; y: number }>());
  const pinch = useRef({ distance: 1, size: 56 });

  // Center the selected element whenever the sheet opens.
  useEffect(() => {
    if (!open) return;
    const grid = gridRef.current;
    if (!grid) return;
    const el = grid.querySelector<HTMLElement>(`[data-z="${selected}"]`);
    if (el) {
      grid.scrollTo({
        left: el.offsetLeft - grid.clientWidth / 2 + el.offsetWidth / 2,
        top: el.offsetTop - grid.clientHeight / 2 + el.offsetHeight / 2,
      });
    }
  }, [open, selected]);

  // Ctrl/⌘ + wheel (also trackpad pinch) zooms the table.
  useEffect(() => {
    const grid = gridRef.current;
    if (!grid) return;
    const onWheel = (e: WheelEvent): void => {
      if (!e.ctrlKey) return;
      e.preventDefault();
      setSize((s) => clampSize(s * (e.deltaY < 0 ? 1.08 : 0.93)));
    };
    grid.addEventListener('wheel', onWheel, { passive: false });
    return () => grid.removeEventListener('wheel', onWheel);
  }, []);

  const distance = (): number => {
    const pts = Array.from(pointers.current.values());
    return pts.length === 2 ? Math.hypot(pts[0].x - pts[1].x, pts[0].y - pts[1].y) : 0;
  };

  const onPointerDown = (e: ReactPointerEvent<HTMLDivElement>): void => {
    pointers.current.set(e.pointerId, { x: e.clientX, y: e.clientY });
    if (pointers.current.size === 2) pinch.current = { distance: distance() || 1, size };
  };
  const onPointerMove = (e: ReactPointerEvent<HTMLDivElement>): void => {
    if (!pointers.current.has(e.pointerId)) return;
    pointers.current.set(e.pointerId, { x: e.clientX, y: e.clientY });
    if (pointers.current.size === 2) setSize(clampSize((pinch.current.size * distance()) / pinch.current.distance));
  };
  const onPointerEnd = (e: ReactPointerEvent<HTMLDivElement>): void => {
    pointers.current.delete(e.pointerId);
  };

  const gridStyle = {
    '--cs': `${size}px`,
    gridTemplateColumns: `repeat(18, ${size}px)`,
    gridTemplateRows: `26px repeat(7, ${Math.round(size * 1.2)}px) 8px repeat(2, ${Math.round(size * 1.2)}px)`,
  } as CSSProperties;

  return (
    <Sheet open={open} label="Periodic table" onClose={onClose} tall>
      <SheetHeader
        title="Periodic Table"
        onClose={onClose}
        left={
          <div className="flex gap-1">
            <button type="button" className="round-btn flat" onClick={() => setSize((s) => clampSize(s - 8))} aria-label="Zoom out">
              <MinusIcon />
            </button>
            <button type="button" className="round-btn flat" onClick={() => setSize((s) => clampSize(s + 8))} aria-label="Zoom in">
              <PlusIcon />
            </button>
          </div>
        }
      />
      <div className="flex gap-2 overflow-x-auto px-3.5 py-2.5" role="group" aria-label="Table options">
        <span className="chip num">
          {found.size} / {ELEMENT_COUNT}
        </span>
        <button type="button" className="chip chip-btn" onClick={onQuiz}>
          Quiz
        </button>
        {LAYERS.map((l) => (
          <button key={l.id} type="button" className="chip chip-btn" aria-pressed={layer === l.id} style={layer === l.id ? { background: '#fff', color: '#0b1031' } : undefined} onClick={() => onLayer(l.id)}>
            {l.label}
          </button>
        ))}
      </div>
      <div
        ref={gridRef}
        className="grid-table"
        style={gridStyle}
        onPointerDown={onPointerDown}
        onPointerMove={onPointerMove}
        onPointerUp={onPointerEnd}
        onPointerCancel={onPointerEnd}
        onPointerLeave={onPointerEnd}
      >
        {Array.from({ length: 18 }, (_, i) => (
          <em key={i} aria-hidden="true" style={{ gridColumn: i + 1, gridRow: 1 }}>
            {i + 1}
          </em>
        ))}
        {ELEMENTS.map((e) => {
          const isFound = found.has(e.z);
          return (
            <button
              key={e.z}
              type="button"
              data-z={e.z}
              className={`cell ${isFound ? '' : 'locked'} ${e.z === selected ? 'selected' : ''}`}
              style={
                { gridColumn: e.col, gridRow: e.row + 1, '--c': layerColor(e, layer), '--d': `${e.z * 8}ms` } as CSSProperties
              }
              aria-label={isFound ? `${e.name}, atomic number ${e.z}` : `Undiscovered element, atomic number ${e.z}. Tap to discover.`}
              aria-current={e.z === selected ? 'true' : undefined}
              onClick={(ev) => onPick(e.z, ev.currentTarget.querySelector('b'))}
            >
              <i>{e.z}</i>
              <b>{isFound ? e.symbol : '?'}</b>
            </button>
          );
        })}
      </div>
      <div className="flex gap-3 overflow-x-auto px-4 pb-3 pt-1 text-[12px] font-semibold text-mut" aria-label="Legend">
        {LAYER_LEGEND[layer].map((item) => (
          <span key={item.label} className="flex flex-none items-center gap-1.5">
            <span className="inline-block h-2.5 w-2.5 rounded-full" style={{ background: item.color }} />
            {item.label}
          </span>
        ))}
      </div>
    </Sheet>
  );
}
