'use client';

import dynamic from 'next/dynamic';
import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import type { CSSProperties } from 'react';
import { CubeIcon, DownIcon, GridIcon, UpIcon } from '@/components/Icons';
import { DetailSheet } from '@/components/DetailSheet';
import { QuizSheet } from '@/components/QuizSheet';
import { RailPill } from '@/components/RailPill';
import { SearchSheet } from '@/components/SearchSheet';
import { TableSheet } from '@/components/TableSheet';
import { TopBar } from '@/components/TopBar';
import { useMediaQuery } from '@/hooks/useMediaQuery';
import { useTheme } from '@/hooks/useTheme';
import {
  CATEGORY_META,
  CATEGORY_ORDER,
  ELEMENT_COUNT,
  PHASE_LABEL,
  approxNeutrons,
  findElement,
  formatMass,
  getElement,
  groupLabel,
  layerColor,
  neighbor,
} from '@/lib/elements';
import type { Dir, Layer } from '@/lib/elements';
import { defaultProgress, loadProgress, saveProgress, vibrate } from '@/lib/storage';
import type { Progress } from '@/lib/storage';

// three.js only runs in the browser, so it is loaded lazily and never server-rendered.
const Scene3D = dynamic(() => import('@/components/Scene3D'), { ssr: false });

type SheetId = 'table' | 'detail' | 'quiz' | 'search';
const LAYER_KEY = 'elements:layer';

function isLayer(value: string | null): value is Layer {
  return value === 'category' || value === 'phase' || value === 'block' || value === 'electronegativity';
}

function Confetti({ burst }: { burst: number }) {
  const pieces = useMemo(
    () =>
      burst === 0
        ? []
        : Array.from({ length: 28 }, (_, id) => ({
            id,
            color: CATEGORY_META[CATEGORY_ORDER[id % CATEGORY_ORDER.length]].color,
            x: (Math.random() - 0.5) * 340,
            y: -120 - Math.random() * 220,
            r: Math.random() * 720,
          })),
    [burst],
  );
  return (
    <div key={burst} aria-hidden="true">
      {pieces.map((p) => (
        <i
          key={p.id}
          className="confetti"
          style={{ left: '50%', top: '45%', background: p.color, '--x': `${p.x}px`, '--y': `${p.y}px`, '--r': `${p.r}deg` } as CSSProperties}
        />
      ))}
    </div>
  );
}

export default function ElementsApp() {
  const reduced = useMediaQuery('(prefers-reduced-motion: reduce)');
  const [theme, setTheme] = useTheme();
  const [z, setZ] = useState(8);
  const [progress, setProgress] = useState<Progress>(defaultProgress);
  const [ready, setReady] = useState(false);
  const [sheet, setSheet] = useState<SheetId | null>(null);
  const [menu, setMenu] = useState(false);
  const [layer, setLayer] = useState<Layer>('category');
  const [spread, setSpread] = useState(false);
  const [holding, setHolding] = useState(false);
  const [pulse, setPulse] = useState(0);
  const [edge, setEdge] = useState<{ dir: Dir; key: number }>({ dir: 'left', key: 0 });
  const [toastOn, setToastOn] = useState(false);
  const [toastMessage, setToastMessage] = useState('');
  const [burst, setBurst] = useState(0);
  const [hinted, setHinted] = useState(false);
  const toastTimer = useRef<number | undefined>(undefined);

  const el = getElement(z);
  const color = layerColor(el, layer);
  const found = useMemo(() => new Set(progress.found), [progress.found]);
  const foundRef = useRef<ReadonlySet<number>>(found);
  useEffect(() => {
    foundRef.current = found;
  }, [found]);

  // ---- load saved state and deep link (?e=O, ?e=8, ?e=oxygen) ----
  useEffect(() => {
    const loaded = loadProgress();
    const param = new URLSearchParams(window.location.search).get('e');
    const target = param ? findElement(param) : undefined;
    if (target) {
      setZ(target.z);
      if (!loaded.found.includes(target.z)) loaded.found = [...loaded.found, target.z];
    }
    setProgress(loaded);
    try {
      const storedLayer = window.localStorage.getItem(LAYER_KEY);
      if (isLayer(storedLayer)) setLayer(storedLayer);
    } catch {
      /* storage unavailable */
    }
    setReady(true);
  }, []);

  useEffect(() => {
    if (ready) saveProgress(progress);
  }, [ready, progress]);

  useEffect(() => {
    if (!ready) return;
    try {
      window.localStorage.setItem(LAYER_KEY, layer);
    } catch {
      /* storage unavailable */
    }
  }, [ready, layer]);

  useEffect(() => {
    if (!ready) return;
    const url = new URL(window.location.href);
    url.searchParams.set('e', el.symbol);
    window.history.replaceState(window.history.state, '', url);
  }, [ready, el.symbol]);

  useEffect(() => () => window.clearTimeout(toastTimer.current), []);

  // ---- actions ----
  const showToast = useCallback((message: string): void => {
    setToastMessage(message);
    setToastOn(true);
    window.clearTimeout(toastTimer.current);
    toastTimer.current = window.setTimeout(() => setToastOn(false), 1800);
  }, []);

  const select = useCallback(
    (target: number, bubble?: HTMLElement | null): void => {
      const next = getElement(target);
      const isNew = !foundRef.current.has(next.z);
      setZ(next.z);
      setPulse((n) => n + 1);
      setHinted(true);
      if (isNew) {
        setProgress((p) => (p.found.includes(next.z) ? p : { ...p, found: [...p.found, next.z], xp: p.xp + 10 }));
        showToast(`Discovered ${next.name} · +10 XP`);
        vibrate([12, 30, 12]);
        if (bubble) {
          bubble.classList.add('pop');
          window.setTimeout(() => bubble.classList.remove('pop'), 700);
        }
      } else {
        vibrate(10);
      }
    },
    [showToast],
  );

  const go = useCallback(
    (dir: Dir): void => {
      const target = neighbor(z, dir);
      if (target === null) {
        setEdge((e) => ({ dir, key: e.key + 1 }));
        vibrate(6);
        return;
      }
      select(target);
    },
    [z, select],
  );

  const openSheet = useCallback((id: SheetId): void => {
    setMenu(false);
    setSheet(id);
  }, []);
  const closeSheet = useCallback((): void => setSheet(null), []);
  const closeMenu = useCallback((): void => setMenu(false), []);

  const answer = useCallback(
    (correct: boolean): void => {
      if (correct) {
        if ((progress.streak + 1) % 3 === 0) setBurst((b) => b + 1);
        vibrate([10, 20, 10]);
        showToast('+5 XP');
      } else {
        vibrate(30);
      }
      setProgress((p) => {
        if (!correct) return p.streak === 0 ? p : { ...p, streak: 0 };
        const streak = p.streak + 1;
        return { ...p, streak, best: Math.max(p.best, streak), xp: p.xp + 5 };
      });
    },
    [progress.streak, showToast],
  );

  const reset = useCallback((): void => {
    setProgress(defaultProgress());
    setZ(8);
    setPulse((n) => n + 1);
    showToast('Progress reset');
  }, [showToast]);

  // ---- keyboard: arrows travel, / searches, g opens the table, Escape closes ----
  useEffect(() => {
    const onKey = (e: KeyboardEvent): void => {
      if (e.defaultPrevented || e.metaKey || e.ctrlKey || e.altKey) return;
      if (e.key === 'Escape') {
        setSheet(null);
        setMenu(false);
        return;
      }
      const target = e.target;
      const typing =
        target instanceof HTMLElement && (target.tagName === 'INPUT' || target.tagName === 'TEXTAREA' || target.isContentEditable);
      if (typing) return;
      const arrows: Readonly<Record<string, Dir>> = { ArrowUp: 'up', ArrowDown: 'down', ArrowLeft: 'left', ArrowRight: 'right' };
      const dir = arrows[e.key];
      if (dir !== undefined) {
        if (sheet === null) {
          e.preventDefault();
          go(dir);
        }
        return;
      }
      if (e.key === '/') {
        e.preventDefault();
        openSheet('search');
      } else if (e.key === 'g' || e.key === 'G') {
        if (sheet === null) openSheet('table');
      }
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [go, openSheet, sheet]);

  const onSceneTap = useCallback((): void => {
    if (sheet !== null || menu) {
      setSheet(null);
      setMenu(false);
    } else {
      vibrate(8);
    }
    setHinted(true);
  }, [sheet, menu]);

  const pickFromTable = useCallback(
    (target: number, bubble: HTMLElement | null): void => {
      select(target, bubble);
      window.setTimeout(() => setSheet((current) => (current === 'table' ? null : current)), 420);
    },
    [select],
  );

  const pickFromSearch = useCallback(
    (target: number): void => {
      select(target);
      setSheet(null);
    },
    [select],
  );

  const tint = { background: `radial-gradient(60vmax 60vmax at 50% 48%, ${color}20, transparent)` };

  return (
    <main className="relative mx-auto h-dvh w-full max-w-[520px] select-none overflow-hidden" aria-label="Interactive periodic table">
      <h1 className="sr-only">Elements: an interactive periodic table of all 118 elements</h1>

      <Scene3D
        symbol={el.symbol}
        name={el.name}
        color={color}
        electrons={Math.min(12, el.z)}
        spread={spread || holding}
        lifted={sheet !== null}
        reduced={reduced}
        pulse={pulse}
        edgeKey={edge.key}
        edgeDir={edge.dir}
        onSwipe={go}
        onTap={onSceneTap}
        onHold={setHolding}
      />

      <div key={`${z}-${layer}`} className="tint pointer-events-none absolute inset-0" style={tint} aria-hidden="true" />
      <div
        className="ghost num pointer-events-none absolute inset-x-0 top-[12%] text-center text-[length:clamp(96px,38vw,150px)] font-bold leading-none opacity-[0.06]"
        aria-hidden="true"
      >
        {String(el.z).padStart(2, '0')}
      </div>

      <TopBar
        found={found.size}
        total={ELEMENT_COUNT}
        xp={progress.xp}
        menuOpen={menu}
        theme={theme}
        layer={layer}
        onSearch={() => openSheet('search')}
        onToggleMenu={() => setMenu((m) => !m)}
        onCloseMenu={closeMenu}
        onTheme={setTheme}
        onLayer={setLayer}
        onReset={reset}
      />

      <RailPill label="Period" value={el.period} axis="y" side="left" onStep={go} />
      <RailPill label="Group" value={groupLabel(el)} axis="x" side="right" onStep={go} />
      <button type="button" className="round-btn small glass absolute right-1 top-[24%] z-[2]" onClick={() => go('up')} aria-label="Move up the table">
        <UpIcon size={16} />
      </button>
      <button type="button" className="round-btn small glass absolute right-1 top-[54%] z-[2]" onClick={() => go('down')} aria-label="Move down the table">
        <DownIcon size={16} />
      </button>

      <p
        className={`hint pointer-events-none absolute inset-x-0 top-[67%] m-0 text-center text-[13px] font-semibold text-mut transition-opacity duration-500 ${hinted ? 'opacity-0' : ''}`}
      >
        Swipe to travel · Hold to peek · Tap to bounce
      </p>

      <div className="pointer-events-none absolute inset-x-3 bottom-[max(16px,env(safe-area-inset-bottom))] z-[3] flex items-end justify-between">
        <button
          type="button"
          className="round-btn glass pointer-events-auto"
          aria-pressed={spread}
          aria-label="Spread the electrons"
          onClick={() => {
            setSpread((s) => !s);
            vibrate(8);
          }}
        >
          <CubeIcon size={22} />
        </button>
        <button
          type="button"
          className="glass pointer-events-auto flex h-[46px] min-w-44 max-w-[calc(100%-120px)] flex-col items-center justify-center rounded-full px-4 transition-transform duration-500 ease-out active:scale-95"
          onClick={() => openSheet('detail')}
          aria-label={`${el.name} details`}
        >
          <span className="max-w-full truncate text-[15px] font-extrabold leading-tight">
            {el.name} <span className="num text-[13px] font-medium text-mut">{formatMass(el)}</span>
          </span>
          <span className="max-w-full truncate text-xs font-semibold leading-tight text-mut">
            {CATEGORY_META[el.category].label} · {PHASE_LABEL[el.phase]}
          </span>
        </button>
        <button type="button" className="round-btn glass pointer-events-auto" onClick={() => openSheet('table')} aria-label="Open the periodic table">
          <GridIcon size={22} />
        </button>
      </div>

      <div className={`peek glass num ${holding ? 'on' : ''}`} role="status" aria-live="polite">
        {el.z} protons · {el.z} electrons · ≈{approxNeutrons(el)} neutrons
      </div>
      <div className={`toast glass num ${toastOn ? 'on' : ''}`} role="status" aria-live="polite">
        {toastMessage}
      </div>

      <TableSheet
        open={sheet === 'table'}
        selected={z}
        found={found}
        layer={layer}
        onPick={pickFromTable}
        onLayer={setLayer}
        onQuiz={() => openSheet('quiz')}
        onClose={closeSheet}
      />
      <DetailSheet open={sheet === 'detail'} element={el} color={color} onClose={closeSheet} onToast={showToast} />
      <QuizSheet open={sheet === 'quiz'} found={found} streak={progress.streak} best={progress.best} onAnswer={answer} onClose={closeSheet} />
      <SearchSheet open={sheet === 'search'} onPick={pickFromSearch} onClose={closeSheet} />

      <Confetti burst={burst} />
    </main>
  );
}
