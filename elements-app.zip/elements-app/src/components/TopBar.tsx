'use client';

import { useEffect, useRef, useState } from 'react';
import { MoreIcon, SearchIcon } from '@/components/Icons';
import { LAYERS } from '@/lib/elements';
import type { Layer } from '@/lib/elements';
import { THEMES } from '@/hooks/useTheme';
import type { ThemePref } from '@/hooks/useTheme';

interface TopBarProps {
  found: number;
  total: number;
  xp: number;
  menuOpen: boolean;
  theme: ThemePref;
  layer: Layer;
  onSearch: () => void;
  onToggleMenu: () => void;
  onCloseMenu: () => void;
  onTheme: (theme: ThemePref) => void;
  onLayer: (layer: Layer) => void;
  onReset: () => void;
}

export function TopBar(props: TopBarProps) {
  const { found, total, xp, menuOpen, theme, layer, onSearch, onToggleMenu, onCloseMenu, onTheme, onLayer, onReset } = props;
  const wrapRef = useRef<HTMLDivElement>(null);
  const [confirming, setConfirming] = useState(false);

  // Close the menu on outside press.
  useEffect(() => {
    if (!menuOpen) {
      setConfirming(false);
      return;
    }
    const onDown = (e: PointerEvent): void => {
      if (wrapRef.current && e.target instanceof Node && !wrapRef.current.contains(e.target)) onCloseMenu();
    };
    document.addEventListener('pointerdown', onDown);
    return () => document.removeEventListener('pointerdown', onDown);
  }, [menuOpen, onCloseMenu]);

  return (
    <div ref={wrapRef} className="pointer-events-none absolute inset-x-0 top-[max(8px,env(safe-area-inset-top))] z-[3] px-3">
      <div className="flex items-center justify-between">
        <button type="button" className="round-btn glass pointer-events-auto" onClick={onSearch} aria-label="Search elements (press /)">
          <SearchIcon />
        </button>
        <p className="num m-0 text-[13px] text-mut" aria-live="polite">
          {found} / {total} · {xp} XP
        </p>
        <button
          type="button"
          className="round-btn glass pointer-events-auto"
          onClick={onToggleMenu}
          aria-label="Theme and settings"
          aria-expanded={menuOpen}
          aria-controls="settings-menu"
        >
          <MoreIcon />
        </button>
      </div>

      <div id="settings-menu" className={`popover glass pointer-events-auto top-14 ${menuOpen ? 'open' : ''}`} inert={!menuOpen}>
        <p className="mb-2 mt-0 text-xs font-bold text-mut">Theme</p>
        <div className="seg" role="group" aria-label="Theme">
          {THEMES.map((t) => (
            <button key={t.id} type="button" aria-pressed={theme === t.id} onClick={() => onTheme(t.id)}>
              {t.label}
            </button>
          ))}
        </div>
        <p className="mb-2 mt-4 text-xs font-bold text-mut">Color the table by</p>
        <div className="seg flex-wrap" role="group" aria-label="Color the table by">
          {LAYERS.map((l) => (
            <button key={l.id} type="button" aria-pressed={layer === l.id} onClick={() => onLayer(l.id)}>
              {l.label}
            </button>
          ))}
        </div>
        <button
          type="button"
          className="chip chip-btn mt-4 w-full justify-center"
          onClick={() => {
            if (confirming) {
              onReset();
              setConfirming(false);
              onCloseMenu();
            } else {
              setConfirming(true);
            }
          }}
        >
          {confirming ? 'Tap again to reset progress' : 'Reset progress'}
        </button>
      </div>
    </div>
  );
}
