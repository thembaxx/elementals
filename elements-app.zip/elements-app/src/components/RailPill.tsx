'use client';

import { useRef } from 'react';
import type { PointerEvent as ReactPointerEvent } from 'react';
import type { Dir } from '@/lib/elements';
import { vibrate } from '@/lib/storage';

interface RailPillProps {
  label: string;
  value: string | number;
  axis: 'x' | 'y';
  side: 'left' | 'right';
  onStep: (dir: Dir) => void;
}

/** White pill pinned to a screen edge. Dragging it along its axis steps through the table. */
export function RailPill({ label, value, axis, side, onStep }: RailPillProps) {
  const ref = useRef<HTMLDivElement>(null);
  const start = useRef<number | null>(null);

  const coord = (e: ReactPointerEvent<HTMLDivElement>): number => (axis === 'y' ? e.clientY : e.clientX);

  const onDown = (e: ReactPointerEvent<HTMLDivElement>): void => {
    start.current = coord(e);
    e.currentTarget.setPointerCapture(e.pointerId);
    if (ref.current) ref.current.style.transition = 'none';
  };

  const onMove = (e: ReactPointerEvent<HTMLDivElement>): void => {
    if (start.current === null) return;
    const v = coord(e);
    const d = v - start.current;
    const offset = Math.max(-16, Math.min(16, d * 0.3));
    if (ref.current) ref.current.style.transform = axis === 'y' ? `translateY(${offset}px)` : `translateX(${offset}px)`;
    if (Math.abs(d) > 34) {
      start.current = v;
      onStep(axis === 'y' ? (d > 0 ? 'down' : 'up') : d > 0 ? 'right' : 'left');
      vibrate(4);
    }
  };

  const onEnd = (): void => {
    start.current = null;
    if (ref.current) {
      ref.current.style.transition = '';
      ref.current.style.transform = '';
    }
  };

  return (
    <div
      ref={ref}
      role="group"
      aria-label={`${label}. Drag ${axis === 'y' ? 'up or down' : 'left or right'} to change.`}
      className={`white-pill absolute top-[38%] z-[2] touch-none cursor-grab ${side === 'left' ? 'left-3' : 'right-3'}`}
      onPointerDown={onDown}
      onPointerMove={onMove}
      onPointerUp={onEnd}
      onPointerCancel={onEnd}
    >
      {label} <span className="num">{value}</span>
    </div>
  );
}
