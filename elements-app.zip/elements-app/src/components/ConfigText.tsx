/** Renders an electron configuration such as "[Ar] 3d6 4s2" with proper superscripts. */
export function ConfigText({ config }: { config: string }) {
  return (
    <span className="num">
      {config.split(' ').map((token, i) => {
        const match = /^(\d[spdf])(\d+)$/.exec(token);
        return (
          <span key={i}>
            {i > 0 ? ' ' : ''}
            {match ? (
              <>
                {match[1]}
                <sup>{match[2]}</sup>
              </>
            ) : (
              token
            )}
          </span>
        );
      })}
    </span>
  );
}
