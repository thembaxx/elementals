'use client';

import { useCallback, useEffect, useRef, useState } from 'react';
import { ELEMENTS } from '@/data/elements';
import { Sheet, SheetHeader } from '@/components/Sheet';
import { buildQuestion } from '@/lib/elements';
import type { QuizQuestion } from '@/lib/elements';

interface QuizSheetProps {
  open: boolean;
  found: ReadonlySet<number>;
  streak: number;
  best: number;
  onAnswer: (correct: boolean) => void;
  onClose: () => void;
}

export function QuizSheet({ open, found, streak, best, onAnswer, onClose }: QuizSheetProps) {
  const [question, setQuestion] = useState<QuizQuestion | null>(null);
  const [picked, setPicked] = useState<string | null>(null);
  const [round, setRound] = useState(0);
  const foundRef = useRef(found);
  const timer = useRef<number | undefined>(undefined);

  useEffect(() => {
    foundRef.current = found;
  }, [found]);

  const next = useCallback((): void => {
    const pool = foundRef.current.size >= 6 ? Array.from(foundRef.current) : ELEMENTS.map((e) => e.z);
    setQuestion(buildQuestion(pool));
    setPicked(null);
    setRound((r) => r + 1);
  }, []);

  useEffect(() => {
    if (open) next();
    return () => window.clearTimeout(timer.current);
  }, [open, next]);

  const choose = (option: string): void => {
    if (!question || picked !== null) return;
    setPicked(option);
    onAnswer(option === question.answer);
    timer.current = window.setTimeout(next, 1100);
  };

  return (
    <Sheet open={open} label="Quiz" onClose={onClose}>
      <SheetHeader
        title="Quiz"
        onClose={onClose}
        left={
          <span className="num whitespace-nowrap text-[12px] font-bold text-mut" aria-live="polite">
            Streak {streak}
          </span>
        }
      />
      <div className="sheet-scroll">
        {question ? (
          <div key={round} className="card flip glass">
            <p className="m-0 text-[15px] font-bold text-mut">{question.prompt}</p>
            <p className={`mx-0 mb-5 mt-1 text-[30px] font-extrabold leading-tight ${question.kind === 'name' ? 'num' : ''}`}>{question.subject}</p>
            <div className="grid grid-cols-2 gap-2.5">
              {question.options.map((option) => {
                const isAnswer = picked !== null && option === question.answer;
                const isWrong = picked === option && option !== question.answer;
                return (
                  <button
                    key={option}
                    type="button"
                    disabled={picked !== null}
                    className={`opt ${isAnswer ? 'ok' : ''} ${isWrong ? 'no' : ''}`}
                    onClick={() => choose(option)}
                  >
                    {option}
                  </button>
                );
              })}
            </div>
            <p className="num mb-0 mt-4 text-[12px] text-mut" role="status">
              {picked === null ? `Best streak ${best}` : picked === question.answer ? 'Correct! +5 XP' : `It was ${question.answer}`}
            </p>
          </div>
        ) : null}
      </div>
    </Sheet>
  );
}
