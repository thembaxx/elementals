interface ShellDiagramProps {
  shells: readonly number[];
  color: string;
  size?: number;
  label: string;
}

/** Bohr-style diagram: one ring per electron shell. Pure and deterministic, so it renders on the server too. */
export function ShellDiagram({ shells, color, size = 190, label }: ShellDiagramProps) {
  const last = Math.max(shells.length - 1, 1);
  return (
    <svg
      viewBox="0 0 260 260"
      width={size}
      height={size}
      role="img"
      aria-label={label}
      style={{ display: 'block', margin: '0 auto', color: 'var(--ink)' }}
    >
      <circle cx="130" cy="130" r="12" fill={color} />
      {shells.map((count, i) => {
        const radius = shells.length > 1 ? 26 + i * (98 / last) : 70;
        const dots = Array.from({ length: count }, (_, k) => {
          const angle = (k / count) * Math.PI * 2 + i * 0.6;
          return (
            <circle
              key={k}
              cx={(130 + radius * Math.cos(angle)).toFixed(2)}
              cy={(130 + radius * Math.sin(angle)).toFixed(2)}
              r="4"
              fill={color}
            />
          );
        });
        return (
          <g key={i}>
            <circle cx="130" cy="130" r={radius} fill="none" stroke="currentColor" strokeOpacity="0.25" strokeWidth="1.5" />
            {dots}
          </g>
        );
      })}
    </svg>
  );
}
