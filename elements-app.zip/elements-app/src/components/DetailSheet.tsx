'use client';

import Link from 'next/link';
import { ALT_NAMES } from '@/data/elements';
import type { ElementRecord } from '@/data/elements';
import { ShareIcon } from '@/components/Icons';
import { Sheet, SheetHeader } from '@/components/Sheet';
import { ConfigText } from '@/components/ConfigText';
import { ShellDiagram } from '@/components/ShellDiagram';
import { CATEGORY_META, PHASE_LABEL, approxNeutrons, formatMass, groupLabel } from '@/lib/elements';

interface DetailSheetProps {
  open: boolean;
  element: ElementRecord;
  color: string;
  onClose: () => void;
  onToast: (message: string) => void;
}

export function DetailSheet({ open, element: e, color, onClose, onToast }: DetailSheetProps) {
  const share = async (): Promise<void> => {
    const url = `${window.location.origin}/?e=${e.symbol}`;
    try {
      if (typeof navigator.share === 'function') {
        await navigator.share({ title: `${e.name} (${e.symbol})`, text: e.fact, url });
        return;
      }
      await navigator.clipboard.writeText(url);
      onToast('Link copied');
    } catch {
      /* the share sheet was dismissed or the clipboard is unavailable */
    }
  };

  const facts: readonly { label: string; value: string }[] = [
    { label: 'Atomic no.', value: String(e.z) },
    { label: 'Atomic mass', value: formatMass(e) },
    { label: 'Phase at 0 °C', value: PHASE_LABEL[e.phase] },
    { label: 'Period', value: String(e.period) },
    { label: 'Group', value: groupLabel(e) },
    { label: 'Block', value: `${e.block}-block` },
    { label: 'Electronegativity', value: e.en === null ? '—' : e.en.toFixed(2) },
    { label: 'Discovered', value: e.discovered },
    { label: 'Neutrons (≈)', value: String(approxNeutrons(e)) },
  ];
  const alt = ALT_NAMES[e.z];

  return (
    <Sheet open={open} label={`${e.name} details`} onClose={onClose}>
      <SheetHeader
        title={e.name}
        onClose={onClose}
        left={
          <button type="button" className="round-btn flat" onClick={share} aria-label={`Share ${e.name}`}>
            <ShareIcon />
          </button>
        }
      />
      <div className="sheet-scroll">
        <p className="mx-4 mb-0 mt-2 text-center text-[13px] font-bold text-mut">
          <span className="inline-flex items-center gap-1.5">
            <span className="inline-block h-2.5 w-2.5 rounded-full" style={{ background: color }} />
            {CATEGORY_META[e.category].label}
          </span>
          {alt ? ` · also spelled ${alt}` : ''}
        </p>
        <ShellDiagram shells={e.shells} color={color} label={`Electron shells of ${e.name}: ${e.shells.join(', ')}`} />
        <p className="num mx-4 mb-0 mt-1 text-center text-[13px] text-mut">Shells {e.shells.join(' · ')}</p>
        <p className="mx-5 mb-0 mt-1 text-center text-[13px] text-mut">
          <ConfigText config={e.config} />
          {e.z >= 104 ? ' (predicted)' : ''}
        </p>
        <p className="mx-5 mb-0 mt-3 text-center text-[15px] font-semibold leading-snug">{e.fact}</p>
        <dl className="m-0 grid grid-cols-3 gap-2 px-3.5 pt-3.5">
          {facts.map((f) => (
            <div key={f.label} className="rounded-2xl bg-chip p-2.5">
              <dt className="text-[11px] font-bold text-mut">{f.label}</dt>
              <dd className="num m-0 mt-0.5 text-[14px] font-bold">{f.value}</dd>
            </div>
          ))}
        </dl>
        <div className="flex justify-center px-4 pt-3.5">
          <Link href={`/element/${e.slug}`} prefetch={false} className="chip chip-btn no-underline">
            Open full page
          </Link>
        </div>
      </div>
    </Sheet>
  );
}
