'use client';

import { useEffect, useRef, useState } from 'react';
import type { PointerEvent as ReactPointerEvent } from 'react';
import * as THREE from 'three';
import type { Dir } from '@/lib/elements';

export interface Scene3DProps {
  symbol: string;
  name: string;
  color: string;
  electrons: number;
  spread: boolean;
  lifted: boolean;
  reduced: boolean;
  pulse: number;
  edgeKey: number;
  edgeDir: Dir;
  onSwipe: (dir: Dir) => void;
  onTap: () => void;
  onHold: (on: boolean) => void;
}

interface SceneApi {
  skin: (symbol: string, color: string) => void;
  pulse: () => void;
  wobble: (dir: Dir) => void;
  squash: () => void;
  drag: (dx: number, dy: number) => void;
  parallax: (nx: number, ny: number) => void;
}

interface Gesture {
  x: number;
  y: number;
  lx: number;
  ly: number;
  moved: number;
  timer: number | undefined;
  holding: boolean;
}

function createRenderer(canvas: HTMLCanvasElement): THREE.WebGLRenderer | null {
  try {
    return new THREE.WebGLRenderer({ canvas, alpha: true, antialias: true });
  } catch {
    return null;
  }
}

function spring(x: number, v: number, target: number, k: number, damping: number, dt: number): [number, number] {
  const nv = (v + (target - x) * k * dt) * Math.exp(-damping * dt);
  return [x + nv * dt, nv];
}

/** True when a #rrggbb color is bright enough to need dark text on top of it. */
function isLight(hex: string): boolean {
  const n = parseInt(hex.slice(1), 16);
  if (Number.isNaN(n)) return false;
  const r = (n >> 16) & 255;
  const g = (n >> 8) & 255;
  const b = n & 255;
  return 0.299 * r + 0.587 * g + 0.114 * b > 170;
}

function clamp(v: number, lo: number, hi: number): number {
  return Math.min(hi, Math.max(lo, v));
}

export default function Scene3D(props: Scene3DProps) {
  const hostRef = useRef<HTMLDivElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const sim = useRef<SceneApi | null>(null);
  const live = useRef<Scene3DProps>(props);
  const gesture = useRef<Gesture | null>(null);
  const [webgl, setWebgl] = useState(true);

  // Keep the render loop and gesture handlers reading the latest props without re-creating the scene.
  useEffect(() => {
    live.current = props;
  });

  // ---- scene lifecycle -------------------------------------------------
  useEffect(() => {
    const canvas = canvasRef.current;
    const host = hostRef.current;
    if (!canvas || !host) return;
    const renderer = createRenderer(canvas);
    if (!renderer) {
      setWebgl(false);
      return;
    }
    renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2));

    const geometries: THREE.BufferGeometry[] = [];
    const materials: THREE.Material[] = [];
    const textures: THREE.Texture[] = [];

    const scene = new THREE.Scene();
    const camera = new THREE.PerspectiveCamera(38, 1, 0.1, 80);
    scene.add(new THREE.AmbientLight(0xffffff, 1.95));
    const keyLight = new THREE.DirectionalLight(0xffffff, 2.6);
    keyLight.position.set(-3, 5, 6);
    scene.add(keyLight);
    const rimLight = new THREE.PointLight(0x9fb4ff, 40, 0, 2);
    rimLight.position.set(4, 2, 4);
    scene.add(rimLight);

    const world = new THREE.Group();
    scene.add(world);
    const hero = new THREE.Group();
    world.add(hero);

    // Orb with a painted skin (category color, soft shading, spots and the symbol repeated around the equator).
    const skinCanvas = document.createElement('canvas');
    skinCanvas.width = 1024;
    skinCanvas.height = 512;
    const map = new THREE.CanvasTexture(skinCanvas);
    map.colorSpace = THREE.SRGBColorSpace;
    map.anisotropy = Math.min(8, renderer.capabilities.getMaxAnisotropy());
    textures.push(map);
    const orbGeometry = new THREE.SphereGeometry(1, 64, 40);
    const orbMaterial = new THREE.MeshStandardMaterial({ map, roughness: 0.32, metalness: 0.05 });
    geometries.push(orbGeometry);
    materials.push(orbMaterial);
    const orb = new THREE.Mesh(orbGeometry, orbMaterial);
    orb.position.y = 1;
    hero.add(orb);

    const ringGeometry = new THREE.TorusGeometry(2.3, 0.035, 8, 120);
    const ringMaterial = new THREE.MeshBasicMaterial({ color: 0x363b5e });
    geometries.push(ringGeometry);
    materials.push(ringMaterial);
    const ring = new THREE.Mesh(ringGeometry, ringMaterial);
    ring.rotation.x = Math.PI / 2;
    world.add(ring);

    const shadowGeometry = new THREE.CircleGeometry(1.15, 32);
    const shadowMaterial = new THREE.MeshBasicMaterial({ color: 0x000000, transparent: true, opacity: 0.22 });
    geometries.push(shadowGeometry);
    materials.push(shadowMaterial);
    const shadow = new THREE.Mesh(shadowGeometry, shadowMaterial);
    shadow.rotation.x = -Math.PI / 2;
    shadow.position.y = 0.01;
    world.add(shadow);

    const electronGeometry = new THREE.SphereGeometry(0.1, 16, 12);
    const electronMaterial = new THREE.MeshStandardMaterial({
      color: 0xffffff,
      emissive: 0x8899ff,
      emissiveIntensity: 0.5,
    });
    geometries.push(electronGeometry);
    materials.push(electronMaterial);
    const electrons: THREE.Mesh[] = [];
    for (let i = 0; i < 12; i++) {
      const mesh = new THREE.Mesh(electronGeometry, electronMaterial);
      world.add(mesh);
      electrons.push(mesh);
    }

    const arcPositions: number[] = [];
    for (let i = 0; i < 40; i++) {
      const t = Math.PI - (i / 39) * Math.PI * 0.62;
      arcPositions.push(2.35 * Math.cos(t), 0.2 + 2.6 * Math.sin(t), 0);
    }
    const arcGeometry = new THREE.BufferGeometry();
    arcGeometry.setAttribute('position', new THREE.Float32BufferAttribute(arcPositions, 3));
    const arcMaterial = new THREE.PointsMaterial({ color: 0xffffff, size: 0.075, transparent: true, opacity: 0.75 });
    geometries.push(arcGeometry);
    materials.push(arcMaterial);
    world.add(new THREE.Points(arcGeometry, arcMaterial));

    const dustPositions: number[] = [];
    for (let i = 0; i < 90; i++) {
      dustPositions.push((Math.random() - 0.5) * 16, (Math.random() - 0.3) * 14, (Math.random() - 0.5) * 6 - 3);
    }
    const dustGeometry = new THREE.BufferGeometry();
    dustGeometry.setAttribute('position', new THREE.Float32BufferAttribute(dustPositions, 3));
    const dustMaterial = new THREE.PointsMaterial({ color: 0xffffff, size: 0.04, transparent: true, opacity: 0.5 });
    geometries.push(dustGeometry);
    materials.push(dustMaterial);
    scene.add(new THREE.Points(dustGeometry, dustMaterial));

    // ---- painting the orb skin ----
    let current = { symbol: live.current.symbol, color: live.current.color };
    const fontFamily = (): string =>
      getComputedStyle(document.documentElement).getPropertyValue('--font-nunito').trim() || 'sans-serif';
    const paintSkin = (): void => {
      const ctx = skinCanvas.getContext('2d');
      if (!ctx) return;
      ctx.shadowBlur = 0;
      ctx.fillStyle = current.color;
      ctx.fillRect(0, 0, 1024, 512);
      const shade = ctx.createLinearGradient(0, 0, 0, 512);
      shade.addColorStop(0, 'rgba(255,255,255,0.28)');
      shade.addColorStop(0.55, 'rgba(255,255,255,0)');
      shade.addColorStop(1, 'rgba(0,0,40,0.35)');
      ctx.fillStyle = shade;
      ctx.fillRect(0, 0, 1024, 512);
      // Deterministic spots (seeded from the symbol) so an element always looks the same.
      let seed = 7;
      for (let i = 0; i < current.symbol.length; i++) seed = (seed * 31 + current.symbol.charCodeAt(i)) >>> 0;
      const rand = (): number => {
        seed = (seed * 1664525 + 1013904223) >>> 0;
        return seed / 4294967296;
      };
      for (let i = 0; i < 110; i++) {
        ctx.fillStyle = 'rgba(0,0,30,0.10)';
        ctx.beginPath();
        ctx.arc(rand() * 1024, 40 + rand() * 432, 4 + rand() * 12, 0, Math.PI * 2);
        ctx.fill();
      }
      const len = current.symbol.length;
      ctx.font = `800 ${len > 2 ? 150 : len > 1 ? 190 : 230}px ${fontFamily()}`;
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.shadowColor = 'rgba(5,10,40,0.45)';
      ctx.shadowBlur = 18;
      ctx.fillStyle = isLight(current.color) ? '#0b1031' : '#ffffff';
      for (const u of [0, 0.25, 0.5, 0.75, 1]) ctx.fillText(current.symbol, u * 1024, 262);
      map.needsUpdate = true;
    };
    paintSkin();
    if (document.fonts) {
      document.fonts
        .load(`800 100px ${fontFamily()}`)
        .then(() => paintSkin())
        .catch(() => undefined);
    }

    // ---- theme colors ----
    const readTheme = (): void => {
      const styles = getComputedStyle(document.documentElement);
      ringMaterial.color.set(styles.getPropertyValue('--ring').trim() || '#8fa6d8');
      dustMaterial.color.set(styles.getPropertyValue('--dust').trim() || '#ffffff');
    };
    readTheme();
    const themeObserver = new MutationObserver(readTheme);
    themeObserver.observe(document.documentElement, { attributes: true, attributeFilter: ['data-theme'] });
    const darkQuery = window.matchMedia('(prefers-color-scheme: dark)');
    darkQuery.addEventListener('change', readTheme);

    // ---- sizing ----
    let distance = 10;
    let liftAmount = 2.5;
    const fit = (): void => {
      const w = Math.max(1, host.clientWidth);
      const h = Math.max(1, host.clientHeight);
      renderer.setSize(w, h, false);
      camera.aspect = w / h;
      const tan = Math.tan((19 * Math.PI) / 180);
      distance = Math.max(9, 3.1 / (tan * camera.aspect));
      liftAmount = 2 * tan * distance * 0.2;
      camera.updateProjectionMatrix();
    };
    const resizeObserver = new ResizeObserver(fit);
    resizeObserver.observe(host);
    fit();

    // ---- simulation state ----
    const S = { sc: 1, sv: 0, vy: 0, rx: 0, rv: 0, sp: 1, spv: 0, wy: 0, wv: 0, px: 0, py: 0 };
    sim.current = {
      skin: (symbol, color) => {
        current = { symbol, color };
        paintSkin();
      },
      pulse: () => {
        S.vy = live.current.reduced ? 0 : 14;
        S.sv = -5;
      },
      wobble: (dir) => {
        S.vy = live.current.reduced ? 0 : dir === 'right' ? -6 : dir === 'left' ? 6 : 0;
        S.rv = live.current.reduced ? 0 : dir === 'up' ? 4 : dir === 'down' ? -4 : 0;
        S.sv = -3;
      },
      squash: () => {
        S.sv = -7;
      },
      drag: (dx, dy) => {
        orb.rotation.y += dx * 0.012;
        S.vy = dx * 0.6;
        S.rx = clamp(S.rx + dy * 0.005, -0.6, 0.6);
      },
      parallax: (nx, ny) => {
        S.px = nx;
        S.py = ny;
      },
    };

    let raf = 0;
    let last = 0;
    let time = 0;
    const loop = (ms: number): void => {
      raf = requestAnimationFrame(loop);
      const dt = Math.min((ms - last) / 1000 || 0.016, 0.05);
      last = ms;
      const p = live.current;
      time += dt * (p.reduced ? 0.3 : 1);

      let a = spring(S.sc, S.sv, 1, 170, 9, dt);
      S.sc = a[0];
      S.sv = a[1];
      hero.scale.set(1 + (1 - S.sc) * 0.5, S.sc, 1 + (1 - S.sc) * 0.5);
      hero.position.y = p.reduced ? 0 : Math.sin(time * 1.6) * 0.035;

      const settling = Math.abs(S.vy) < 0.8 && gesture.current === null;
      if (settling) {
        const quarter = Math.PI / 2;
        S.vy += (Math.round(orb.rotation.y / quarter) * quarter - orb.rotation.y) * 60 * dt;
      }
      orb.rotation.y += S.vy * dt;
      S.vy *= Math.exp(-(settling ? 7 : 1.8) * dt);
      a = spring(S.rx, S.rv, 0, 60, 6, dt);
      S.rx = a[0];
      S.rv = a[1];
      orb.rotation.x = S.rx;

      a = spring(S.sp, S.spv, p.spread ? 1.7 : 1, 90, 7, dt);
      S.sp = a[0];
      S.spv = a[1];
      a = spring(S.wy, S.wv, p.lifted ? liftAmount : 0, 70, 8, dt);
      S.wy = a[0];
      S.wv = a[1];
      world.position.y = S.wy;

      const count = clamp(p.electrons, 0, electrons.length);
      electrons.forEach((mesh, i) => {
        mesh.visible = i < count;
        const angle = time * (0.6 + 0.12 * (i % 4)) + i * 2.1;
        if (i % 2 === 0) {
          const r = 2.3 * S.sp;
          mesh.position.set(r * Math.cos(angle), 0.08, r * Math.sin(angle));
        } else {
          const r = 1.75 * S.sp;
          const tilt = i % 4 < 2 ? 0.9 : -0.9;
          const x = r * Math.cos(angle);
          mesh.position.set(x * Math.cos(tilt), 1 + x * Math.sin(tilt), r * Math.sin(angle));
        }
      });

      camera.position.x += (S.px * 0.08 * distance - camera.position.x) * Math.min(1, dt * 4);
      camera.position.y = distance * 0.24 + S.py * 0.05 * distance;
      camera.position.z = distance;
      camera.lookAt(0, 0, 0);
      renderer.render(scene, camera);
    };
    raf = requestAnimationFrame(loop);

    const onContextLost = (event: Event): void => {
      event.preventDefault();
      setWebgl(false);
    };
    canvas.addEventListener('webglcontextlost', onContextLost);

    return () => {
      cancelAnimationFrame(raf);
      sim.current = null;
      canvas.removeEventListener('webglcontextlost', onContextLost);
      themeObserver.disconnect();
      darkQuery.removeEventListener('change', readTheme);
      resizeObserver.disconnect();
      geometries.forEach((g) => g.dispose());
      materials.forEach((m) => m.dispose());
      textures.forEach((t) => t.dispose());
      renderer.dispose();
    };
  }, [webgl]);

  // ---- reacting to prop changes ----
  useEffect(() => {
    sim.current?.skin(props.symbol, props.color);
  }, [props.symbol, props.color]);

  const firstPulse = useRef(true);
  useEffect(() => {
    if (firstPulse.current) {
      firstPulse.current = false;
      return;
    }
    sim.current?.pulse();
  }, [props.pulse]);

  const firstEdge = useRef(true);
  useEffect(() => {
    if (firstEdge.current) {
      firstEdge.current = false;
      return;
    }
    sim.current?.wobble(props.edgeDir);
  }, [props.edgeKey, props.edgeDir]);

  // ---- gestures ----
  const endGesture = (): void => {
    const g = gesture.current;
    gesture.current = null;
    if (!g) return;
    if (g.timer !== undefined) window.clearTimeout(g.timer);
    if (g.holding) live.current.onHold(false);
  };

  const onPointerDown = (e: ReactPointerEvent<HTMLDivElement>): void => {
    if (e.pointerType === 'mouse' && e.button !== 0) return;
    e.currentTarget.setPointerCapture(e.pointerId);
    const g: Gesture = { x: e.clientX, y: e.clientY, lx: e.clientX, ly: e.clientY, moved: 0, timer: undefined, holding: false };
    g.timer = window.setTimeout(() => {
      if (g.moved < 8) {
        g.holding = true;
        live.current.onHold(true);
      }
    }, 450);
    gesture.current = g;
  };

  const onPointerMove = (e: ReactPointerEvent<HTMLDivElement>): void => {
    const rect = e.currentTarget.getBoundingClientRect();
    sim.current?.parallax((e.clientX - rect.left) / rect.width - 0.5, (e.clientY - rect.top) / rect.height - 0.5);
    const g = gesture.current;
    if (!g) return;
    const dx = e.clientX - g.lx;
    const dy = e.clientY - g.ly;
    g.lx = e.clientX;
    g.ly = e.clientY;
    g.moved = Math.max(g.moved, Math.hypot(e.clientX - g.x, e.clientY - g.y));
    if (g.moved > 8) {
      if (g.timer !== undefined) {
        window.clearTimeout(g.timer);
        g.timer = undefined;
      }
      sim.current?.drag(dx, dy);
    }
  };

  const onPointerUp = (e: ReactPointerEvent<HTMLDivElement>): void => {
    const g = gesture.current;
    if (!g) return;
    const dx = e.clientX - g.x;
    const dy = e.clientY - g.y;
    const holding = g.holding;
    const moved = g.moved;
    endGesture();
    if (holding) return;
    if (moved < 8) {
      sim.current?.squash();
      live.current.onTap();
      return;
    }
    if (Math.max(Math.abs(dx), Math.abs(dy)) > 70) {
      if (Math.abs(dx) > Math.abs(dy)) live.current.onSwipe(dx < 0 ? 'right' : 'left');
      else live.current.onSwipe(dy < 0 ? 'down' : 'up');
    }
  };

  return (
    <div
      ref={hostRef}
      className="absolute inset-0 touch-none"
      role="img"
      aria-label={`Interactive 3D model of ${props.name}. Swipe to move across the table, hold to peek at its particles.`}
      onPointerDown={onPointerDown}
      onPointerMove={onPointerMove}
      onPointerUp={onPointerUp}
      onPointerCancel={endGesture}
    >
      {webgl ? (
        <canvas ref={canvasRef} className="absolute inset-0 h-full w-full" />
      ) : (
        <div className="orb-fallback" style={{ background: `radial-gradient(circle at 35% 28%, #fff8, ${props.color} 55%, #0a0e2f)` }}>
          {props.symbol}
        </div>
      )}
    </div>
  );
}
