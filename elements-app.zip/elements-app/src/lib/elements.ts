import { ALT_NAMES, ELEMENTS } from '@/data/elements';
import type { Category, ElementRecord, Phase } from '@/data/elements';

export type Dir = 'up' | 'down' | 'left' | 'right';
export type Layer = 'category' | 'phase' | 'block' | 'electronegativity';

export const ELEMENT_COUNT = ELEMENTS.length;

export const CATEGORY_ORDER: readonly Category[] = [
  'alkali',
  'alkaline',
  'transition',
  'post',
  'metalloid',
  'nonmetal',
  'halogen',
  'noble',
  'lanthanide',
  'actinide',
];

export const CATEGORY_META: Readonly<Record<Category, { label: string; color: string }>> = {
  alkali: { label: 'Alkali metal', color: '#FF5A5F' },
  alkaline: { label: 'Alkaline earth metal', color: '#FF9F43' },
  transition: { label: 'Transition metal', color: '#FFD23F' },
  post: { label: 'Post-transition metal', color: '#2ED8A3' },
  metalloid: { label: 'Metalloid', color: '#20C5E8' },
  nonmetal: { label: 'Nonmetal', color: '#4D8DFF' },
  halogen: { label: 'Halogen', color: '#9B6BFF' },
  noble: { label: 'Noble gas', color: '#FF6BD6' },
  lanthanide: { label: 'Lanthanide', color: '#A3E635' },
  actinide: { label: 'Actinide', color: '#FB7185' },
};

export const PHASE_LABEL: Readonly<Record<Phase, string>> = {
  solid: 'Solid',
  liquid: 'Liquid',
  gas: 'Gas',
  unknown: 'Unknown',
};

export const LAYERS: readonly { id: Layer; label: string }[] = [
  { id: 'category', label: 'Type' },
  { id: 'phase', label: 'Phase' },
  { id: 'block', label: 'Block' },
  { id: 'electronegativity', label: 'Electronegativity' },
];

const UNKNOWN_COLOR = '#9AA3C7';
const PHASE_COLOR: Readonly<Record<Phase, string>> = {
  solid: '#FF9F43',
  liquid: '#20C5E8',
  gas: '#FF6BD6',
  unknown: UNKNOWN_COLOR,
};
const BLOCK_COLOR: Readonly<Record<string, string>> = {
  s: '#FF5A5F',
  p: '#2ED8A3',
  d: '#FFD23F',
  f: '#9B6BFF',
};

export const LAYER_LEGEND: Readonly<Record<Layer, readonly { label: string; color: string }[]>> = {
  category: CATEGORY_ORDER.map((c) => ({ label: CATEGORY_META[c].label, color: CATEGORY_META[c].color })),
  phase: [
    { label: 'Solid', color: PHASE_COLOR.solid },
    { label: 'Liquid', color: PHASE_COLOR.liquid },
    { label: 'Gas', color: PHASE_COLOR.gas },
    { label: 'Unknown', color: PHASE_COLOR.unknown },
  ],
  block: [
    { label: 's-block', color: BLOCK_COLOR.s },
    { label: 'p-block', color: BLOCK_COLOR.p },
    { label: 'd-block', color: BLOCK_COLOR.d },
    { label: 'f-block', color: BLOCK_COLOR.f },
  ],
  electronegativity: [
    { label: 'Low', color: '#20C5E8' },
    { label: 'Medium', color: '#FFD23F' },
    { label: 'High', color: '#FF5A5F' },
    { label: 'Unknown', color: UNKNOWN_COLOR },
  ],
};

const BY_SLUG: ReadonlyMap<string, ElementRecord> = new Map(
  ELEMENTS.map((e): [string, ElementRecord] => [e.slug, e]),
);

export function getElement(z: number): ElementRecord {
  const index = Math.min(Math.max(Math.round(z), 1), ELEMENT_COUNT) - 1;
  return ELEMENTS[index];
}

export function getBySlug(slug: string): ElementRecord | undefined {
  return BY_SLUG.get(slug.toLowerCase());
}

/** Find an element from a symbol, name or atomic number (used for deep links). */
export function findElement(query: string): ElementRecord | undefined {
  const q = query.trim().toLowerCase();
  if (!q) return undefined;
  if (/^\d{1,3}$/.test(q)) {
    const z = Number(q);
    return z >= 1 && z <= ELEMENT_COUNT ? getElement(z) : undefined;
  }
  return ELEMENTS.find((e) => e.slug === q || e.name.toLowerCase() === q);
}

export function formatMass(e: ElementRecord): string {
  return e.unstable ? `(${e.mass})` : e.mass;
}

export function approxNeutrons(e: ElementRecord): number {
  return Math.max(0, Math.round(parseFloat(e.mass)) - e.z);
}

export function periodOf(e: ElementRecord): number {
  return e.period;
}

export function groupLabel(e: ElementRecord): string {
  return e.group === null ? '—' : String(e.group);
}

/** Nearest element in a direction on the table grid (skips empty cells). */
export function neighbor(z: number, dir: Dir): number | null {
  const current = getElement(z);
  const vertical = dir === 'up' || dir === 'down';
  const sign = dir === 'down' || dir === 'right' ? 1 : -1;
  let bestZ: number | null = null;
  let bestDistance = Infinity;
  for (const e of ELEMENTS) {
    const distance = vertical
      ? e.col === current.col
        ? (e.row - current.row) * sign
        : -1
      : e.row === current.row
        ? (e.col - current.col) * sign
        : -1;
    if (distance > 0 && distance < bestDistance) {
      bestDistance = distance;
      bestZ = e.z;
    }
  }
  return bestZ;
}

function hexToRgb(hex: string): [number, number, number] {
  const n = parseInt(hex.slice(1), 16);
  return [(n >> 16) & 255, (n >> 8) & 255, n & 255];
}

function mix(a: string, b: string, t: number): string {
  const x = hexToRgb(a);
  const y = hexToRgb(b);
  const channel = (i: number): string =>
    Math.round(x[i] + (y[i] - x[i]) * t)
      .toString(16)
      .padStart(2, '0');
  return `#${channel(0)}${channel(1)}${channel(2)}`;
}

export function layerColor(e: ElementRecord, layer: Layer): string {
  switch (layer) {
    case 'phase':
      return PHASE_COLOR[e.phase];
    case 'block':
      return BLOCK_COLOR[e.block];
    case 'electronegativity': {
      if (e.en === null) return UNKNOWN_COLOR;
      const t = Math.min(1, Math.max(0, (e.en - 0.7) / (3.98 - 0.7)));
      return t < 0.5 ? mix('#20C5E8', '#FFD23F', t * 2) : mix('#FFD23F', '#FF5A5F', (t - 0.5) * 2);
    }
    default:
      return CATEGORY_META[e.category].color;
  }
}

/** Text that reads well on top of any bubble color. */
export const BUBBLE_INK = '#0B1031';

export function searchElements(query: string, limit = 30): ElementRecord[] {
  const q = query.trim().toLowerCase();
  if (!q) return [];
  const asNumber = /^\d{1,3}$/.test(q) ? Number(q) : null;
  const scored: { e: ElementRecord; score: number }[] = [];
  for (const e of ELEMENTS) {
    const symbol = e.slug;
    const name = e.name.toLowerCase();
    const alt = (ALT_NAMES[e.z] ?? '').toLowerCase();
    const category = CATEGORY_META[e.category].label.toLowerCase();
    let score = 0;
    if (asNumber !== null && e.z === asNumber) score = 100;
    else if (symbol === q) score = 95;
    else if (name === q || alt === q) score = 90;
    else if (name.startsWith(q) || (alt && alt.startsWith(q))) score = 70;
    else if (symbol.startsWith(q)) score = 60;
    else if (name.includes(q) || (alt && alt.includes(q))) score = 40;
    else if (category.includes(q)) score = 20;
    else if (PHASE_LABEL[e.phase].toLowerCase() === q) score = 15;
    else if (e.fact.toLowerCase().includes(q)) score = 10;
    if (score > 0) scored.push({ e, score });
  }
  scored.sort((a, b) => b.score - a.score || a.e.z - b.e.z);
  return scored.slice(0, limit).map((s) => s.e);
}

export type QuizKind = 'symbol' | 'name' | 'number' | 'category';

export interface QuizQuestion {
  kind: QuizKind;
  z: number;
  prompt: string;
  subject: string;
  answer: string;
  options: string[];
}

function attribute(e: ElementRecord, kind: QuizKind): string {
  switch (kind) {
    case 'symbol':
      return e.symbol;
    case 'name':
      return e.name;
    case 'number':
      return String(e.z);
    default:
      return CATEGORY_META[e.category].label;
  }
}

export function buildQuestion(pool: readonly number[], rand: () => number = Math.random): QuizQuestion {
  const source = pool.length > 0 ? pool : ELEMENTS.map((e) => e.z);
  const e = getElement(source[Math.floor(rand() * source.length)]);
  const kinds: readonly QuizKind[] = ['symbol', 'name', 'number', 'category'];
  const kind = kinds[Math.floor(rand() * kinds.length)];
  const answer = attribute(e, kind);
  const options = new Set<string>([answer]);
  for (let i = 0; i < 600 && options.size < 4; i++) {
    const candidate =
      kind === 'category'
        ? CATEGORY_META[CATEGORY_ORDER[Math.floor(rand() * CATEGORY_ORDER.length)]].label
        : attribute(ELEMENTS[Math.floor(rand() * ELEMENT_COUNT)], kind);
    options.add(candidate);
  }
  const list = Array.from(options);
  for (let i = list.length - 1; i > 0; i--) {
    const j = Math.floor(rand() * (i + 1));
    const tmp = list[i];
    list[i] = list[j];
    list[j] = tmp;
  }
  const prompts: Readonly<Record<QuizKind, { prompt: string; subject: string }>> = {
    symbol: { prompt: 'What is the symbol for', subject: e.name },
    name: { prompt: 'Which element has the symbol', subject: e.symbol },
    number: { prompt: 'What is the atomic number of', subject: e.name },
    category: { prompt: 'What type of element is', subject: e.name },
  };
  return { kind, z: e.z, prompt: prompts[kind].prompt, subject: prompts[kind].subject, answer, options: list };
}
