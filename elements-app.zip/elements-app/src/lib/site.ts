export const SITE_URL = (process.env.NEXT_PUBLIC_SITE_URL ?? 'http://localhost:3000').replace(/\/+$/, '');
export const SITE_NAME = 'Elements';
export const SITE_DESCRIPTION =
  'An interactive, gamified periodic table. Spin the 3D elements, explore all 118, search, and quiz yourself.';
