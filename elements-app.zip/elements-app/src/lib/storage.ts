import { ELEMENT_COUNT } from '@/lib/elements';

const KEY = 'elements:progress:v1';

export interface Progress {
  found: number[];
  xp: number;
  streak: number;
  best: number;
}

export function defaultProgress(): Progress {
  return { found: Array.from({ length: 12 }, (_, i) => i + 1), xp: 0, streak: 0, best: 0 };
}

function isInt(value: unknown): value is number {
  return typeof value === 'number' && Number.isInteger(value);
}

export function parseProgress(raw: string | null): Progress {
  const fallback = defaultProgress();
  if (!raw) return fallback;
  try {
    const data: unknown = JSON.parse(raw);
    if (typeof data !== 'object' || data === null) return fallback;
    const record = data as Record<string, unknown>;
    const found = Array.isArray(record.found)
      ? Array.from(new Set(record.found.filter((v): v is number => isInt(v) && v >= 1 && v <= ELEMENT_COUNT)))
      : fallback.found;
    const xp = isInt(record.xp) && record.xp >= 0 ? record.xp : 0;
    const streak = isInt(record.streak) && record.streak >= 0 ? record.streak : 0;
    const best = isInt(record.best) && record.best >= 0 ? record.best : 0;
    return { found, xp, streak, best: Math.max(best, streak) };
  } catch {
    return fallback;
  }
}

export function loadProgress(): Progress {
  try {
    return parseProgress(window.localStorage.getItem(KEY));
  } catch {
    return defaultProgress();
  }
}

export function saveProgress(progress: Progress): void {
  try {
    window.localStorage.setItem(KEY, JSON.stringify(progress));
  } catch {
    /* storage unavailable (private mode or quota): progress simply isn't persisted */
  }
}

export function vibrate(pattern: number | number[]): void {
  try {
    if (typeof navigator !== 'undefined' && typeof navigator.vibrate === 'function') {
      navigator.vibrate(pattern);
    }
  } catch {
    /* haptics are optional */
  }
}
