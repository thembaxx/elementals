'use client';

import { useCallback, useEffect, useState } from 'react';

export type ThemePref = 'auto' | 'midnight' | 'dusk' | 'day';
export const THEMES: readonly { id: ThemePref; label: string }[] = [
  { id: 'auto', label: 'Auto' },
  { id: 'midnight', label: 'Midnight' },
  { id: 'dusk', label: 'Dusk' },
  { id: 'day', label: 'Day' },
];

export const THEME_KEY = 'elements:theme';

function isTheme(value: string | null): value is ThemePref {
  return value === 'auto' || value === 'midnight' || value === 'dusk' || value === 'day';
}

function apply(theme: ThemePref): void {
  const root = document.documentElement;
  if (theme === 'auto') root.removeAttribute('data-theme');
  else root.setAttribute('data-theme', theme);
}

export function useTheme(): [ThemePref, (theme: ThemePref) => void] {
  const [theme, setTheme] = useState<ThemePref>('auto');

  useEffect(() => {
    try {
      const stored = window.localStorage.getItem(THEME_KEY);
      if (isTheme(stored)) setTheme(stored);
    } catch {
      /* storage unavailable */
    }
  }, []);

  const update = useCallback((next: ThemePref) => {
    setTheme(next);
    apply(next);
    try {
      window.localStorage.setItem(THEME_KEY, next);
    } catch {
      /* storage unavailable */
    }
  }, []);

  return [theme, update];
}
