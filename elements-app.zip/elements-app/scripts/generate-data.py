import json
RAW = """H|Hydrogen|1.008|n|g|2.20|1766|The most abundant element in the universe, making up about three quarters of ordinary matter by mass.
He|Helium|4.0026|g|g|-|1895|First detected in the Sun's light in 1868, long before it was found on Earth.
Li|Lithium|6.94|a|s|0.98|1817|The lightest metal. It floats on water and powers rechargeable batteries.
Be|Beryllium|9.0122|e|s|1.57|1798|Gold-coated beryllium forms the mirror segments of the James Webb Space Telescope.
B|Boron|10.81|m|s|2.04|1808|Boron compounds color flames green, and borosilicate glass resists sudden temperature changes.
C|Carbon|12.011|n|s|2.55|Ancient|Diamond and graphite are both pure carbon, arranged in different structures.
N|Nitrogen|14.007|n|g|3.04|1772|Makes up about 78% of Earth's atmosphere.
O|Oxygen|15.999|n|g|3.44|1774|Makes up about 21% of the atmosphere and nearly half of Earth's crust by mass.
F|Fluorine|18.998|h|g|3.98|1886|The most electronegative element, so reactive that it attacks almost everything.
Ne|Neon|20.180|g|g|-|1898|Glows reddish-orange in a discharge tube, the classic color of neon signs.
Na|Sodium|22.990|a|s|0.93|1807|Reacts vigorously with water. Table salt is sodium chloride.
Mg|Magnesium|24.305|e|s|1.31|1808|Burns with a brilliant white flame and sits at the center of every chlorophyll molecule.
Al|Aluminium|26.982|p|s|1.61|1825|The most abundant metal in Earth's crust.
Si|Silicon|28.085|m|s|1.90|1824|The basis of computer chips and a main ingredient of sand and glass.
P|Phosphorus|30.974|n|s|2.19|1669|Essential to DNA and to ATP, the energy currency of cells.
S|Sulfur|32.06|n|s|2.58|Ancient|Burns with a blue flame, and sulfur compounds cause the smell of rotten eggs.
Cl|Chlorine|35.45|h|g|3.16|1774|Widely used to disinfect drinking water and swimming pools.
Ar|Argon|39.948|g|g|-|1894|The third most abundant gas in Earth's atmosphere, at about 0.93%.
K|Potassium|39.098|a|s|0.82|1807|Helps nerves and muscles work, and is found in foods such as bananas and potatoes.
Ca|Calcium|40.078|e|s|1.00|1808|The main mineral in bones and teeth, and a key part of limestone and chalk.
Sc|Scandium|44.956|t|s|1.36|1879|Added to aluminium alloys for lightweight sports equipment.
Ti|Titanium|47.867|t|s|1.54|1791|As strong as steel but about 45% lighter, and highly resistant to corrosion.
V|Vanadium|50.942|t|s|1.63|1801|Small amounts make steel much tougher. Named after the Norse goddess Vanadis.
Cr|Chromium|51.996|t|s|1.66|1797|Gives stainless steel its shine and rubies their red color.
Mn|Manganese|54.938|t|s|1.55|1774|Essential for making steel and needed in tiny amounts by living things.
Fe|Iron|55.845|t|s|1.83|Ancient|Makes up most of Earth's core and lets hemoglobin carry oxygen in your blood.
Co|Cobalt|58.933|t|s|1.88|1735|Gives glass and ceramics the deep blue known as cobalt blue.
Ni|Nickel|58.693|t|s|1.91|1751|Used in coins, stainless steel and rechargeable batteries.
Cu|Copper|63.546|t|s|1.90|Ancient|One of the first metals used by humans and an excellent electrical conductor.
Zn|Zinc|65.38|t|s|1.65|1746|Coats steel in a process called galvanizing to protect it from rust.
Ga|Gallium|69.723|p|s|1.81|1875|Melts at about 30 °C, so a lump can melt in your hand.
Ge|Germanium|72.630|m|s|2.01|1886|A semiconductor used in early transistors and in fiber-optic cables.
As|Arsenic|74.922|m|s|2.18|c. 1250|Famous as a poison, yet also used in semiconductors such as gallium arsenide.
Se|Selenium|78.971|n|s|2.55|1817|Needed in tiny amounts for health and used in photocells and glassmaking.
Br|Bromine|79.904|h|l|2.96|1826|One of only two elements that are liquid at room temperature, a dense reddish-brown liquid.
Kr|Krypton|83.798|g|g|3.00|1898|Its name comes from the Greek for hidden. It is used in some lasers and lighting.
Rb|Rubidium|85.468|a|s|0.82|1861|Used in compact atomic clocks and burns with a reddish-violet flame.
Sr|Strontium|87.62|e|s|0.95|1790|Strontium salts give fireworks a deep red color.
Y|Yttrium|88.906|t|s|1.22|1794|Used in LEDs and lasers. Named after the Swedish village of Ytterby.
Zr|Zirconium|91.224|t|s|1.33|1789|Resists corrosion and absorbs few neutrons, so it clads nuclear fuel rods.
Nb|Niobium|92.906|t|s|1.6|1801|Used in superconducting magnets, including those in MRI scanners.
Mo|Molybdenum|95.95|t|s|2.16|1778|Added to steel so it can withstand high temperatures and pressures.
Tc|Technetium|98|t|s|1.9|1937|The lightest element with no stable isotopes. One isotope is widely used in medical imaging.
Ru|Ruthenium|101.07|t|s|2.2|1844|A hard platinum-group metal used in electrical contacts and chip manufacturing.
Rh|Rhodium|102.91|t|s|2.28|1803|One of the rarest metals, used in the catalytic converters of cars.
Pd|Palladium|106.42|t|s|2.20|1803|Can absorb hundreds of times its own volume of hydrogen gas.
Ag|Silver|107.87|t|s|1.93|Ancient|The best electrical and thermal conductor of any metal.
Cd|Cadmium|112.41|t|s|1.69|1817|Used in nickel-cadmium batteries. Its compounds are toxic.
In|Indium|114.82|p|s|1.78|1863|Indium tin oxide forms the transparent conductive layer in touchscreens.
Sn|Tin|118.71|p|s|1.96|Ancient|Alloyed with copper to make bronze, which gave its name to the Bronze Age.
Sb|Antimony|121.76|m|s|2.05|Ancient|Used in flame retardants, and its compounds were used in cosmetics in ancient times.
Te|Tellurium|127.60|m|s|2.1|1782|Used in thin-film solar panels. Named after the Latin word for Earth.
I|Iodine|126.90|h|s|2.66|1811|Essential for the thyroid gland, which is why table salt is often iodized.
Xe|Xenon|131.29|g|g|2.6|1898|Used in high-intensity lamps and in ion thrusters for spacecraft.
Cs|Caesium|132.91|a|s|0.79|1860|The second is defined by the vibrations of caesium-133 atoms.
Ba|Barium|137.33|e|s|0.89|1808|Barium sulfate is swallowed as a contrast agent for X-ray imaging of the gut.
La|Lanthanum|138.91|l|s|1.10|1839|Its name comes from the Greek for to lie hidden. It is used in camera lenses.
Ce|Cerium|140.12|l|s|1.12|1803|The most abundant rare-earth element, used in lighter flints and catalytic converters.
Pr|Praseodymium|140.91|l|s|1.13|1885|Gives glass and enamels a yellow-green color and is used in strong magnets.
Nd|Neodymium|144.24|l|s|1.14|1885|Neodymium magnets are among the strongest permanent magnets available.
Pm|Promethium|145|l|s|1.13|1945|Has no stable isotopes and is among the rarest elements on Earth.
Sm|Samarium|150.36|l|s|1.17|1879|Samarium-cobalt magnets keep their strength at high temperatures.
Eu|Europium|151.96|l|s|1.2|1901|Europium phosphors produce red light in displays and in euro banknote security features.
Gd|Gadolinium|157.25|l|s|1.2|1880|Used as a contrast agent in MRI scans.
Tb|Terbium|158.93|l|s|1.1|1843|Produces green light in phosphors for lamps and screens.
Dy|Dysprosium|162.50|l|s|1.22|1886|Added to neodymium magnets to help them keep their strength when hot.
Ho|Holmium|164.93|l|s|1.23|1878|Has one of the highest magnetic moments of any element.
Er|Erbium|167.26|l|s|1.24|1843|Amplifies light signals in fiber-optic cables and tints glass pink.
Tm|Thulium|168.93|l|s|1.25|1879|One of the rarest of the rare earths, used in some portable X-ray devices.
Yb|Ytterbium|173.05|l|s|1.1|1878|One of four elements named after the Swedish village of Ytterby.
Lu|Lutetium|174.97|l|s|1.27|1907|The hardest and densest of the lanthanides.
Hf|Hafnium|178.49|t|s|1.3|1923|Used in nuclear reactor control rods and in advanced computer chips.
Ta|Tantalum|180.95|t|s|1.5|1802|Extremely corrosion resistant, and found in capacitors inside phones and laptops.
W|Tungsten|183.84|t|s|2.36|1783|Has the highest melting point of any metal, about 3,422 °C.
Re|Rhenium|186.21|t|s|1.9|1925|One of the rarest elements in Earth's crust, used in jet-engine superalloys.
Os|Osmium|190.23|t|s|2.2|1803|Among the densest naturally occurring elements.
Ir|Iridium|192.22|t|s|2.20|1803|A thin iridium-rich clay layer helped show that an asteroid impact ended the age of dinosaurs.
Pt|Platinum|195.08|t|s|2.28|1735|Highly resistant to corrosion, used in jewelry and catalytic converters.
Au|Gold|196.97|t|s|2.54|Ancient|So malleable that a single gram can be hammered into a sheet about a square meter in size.
Hg|Mercury|200.59|t|l|2.00|Ancient|The only metal that is liquid at room temperature.
Tl|Thallium|204.38|p|s|1.62|1861|Its compounds are highly toxic, and it was once used as a rat poison.
Pb|Lead|207.2|p|s|1.87|Ancient|Once common in pipes and paint, now largely phased out because it is toxic.
Bi|Bismuth|208.98|p|s|2.02|c. 1500|Lab-grown bismuth crystals form colorful, stair-stepped shapes.
Po|Polonium|209|p|s|2.0|1898|Discovered by Marie and Pierre Curie and named after Marie's homeland, Poland.
At|Astatine|210|h|u|2.2|1940|The rarest naturally occurring element in Earth's crust.
Rn|Radon|222|g|g|2.2|1900|A radioactive gas that can build up in buildings. It is the heaviest naturally occurring noble gas.
Fr|Francium|223|a|u|0.7|1939|One of the rarest naturally occurring elements, and extremely radioactive.
Ra|Radium|226|e|s|0.9|1898|Discovered by Marie and Pierre Curie. It glows faintly because of its radioactivity.
Ac|Actinium|227|c|s|1.1|1899|Glows blue in the dark because of its intense radioactivity.
Th|Thorium|232.04|c|s|1.3|1829|Named after the Norse god Thor and studied as a possible fuel for future reactors.
Pa|Protactinium|231.04|c|s|1.5|1913|Its name means before actinium, because it decays into actinium.
U|Uranium|238.03|c|s|1.38|1789|Used as the fuel in nuclear power plants.
Np|Neptunium|237|c|s|1.36|1940|The first transuranic element, meaning the first beyond uranium.
Pu|Plutonium|244|c|s|1.28|1940|Plutonium-238 has powered spacecraft such as the Voyager probes.
Am|Americium|243|c|s|1.3|1944|Americium-241 is used in many household smoke detectors.
Cm|Curium|247|c|s|1.3|1944|Named in honor of Marie and Pierre Curie.
Bk|Berkelium|247|c|s|1.3|1949|Named after Berkeley, California, where it was first produced.
Cf|Californium|251|c|s|1.3|1950|Californium-252 is an intense neutron source used to start up nuclear reactors.
Es|Einsteinium|252|c|s|1.3|1952|Named after Albert Einstein and first found in the debris of a hydrogen bomb test.
Fm|Fermium|257|c|u|1.3|1952|Named after Enrico Fermi and also first found in hydrogen bomb test debris.
Md|Mendelevium|258|c|u|1.3|1955|Named after Dmitri Mendeleev, who created the periodic table.
No|Nobelium|259|c|u|1.3|1958|Named after Alfred Nobel, founder of the Nobel Prizes.
Lr|Lawrencium|266|c|u|-|1961|Named after Ernest Lawrence, inventor of the cyclotron.
Rf|Rutherfordium|267|t|u|-|1969|Named after Ernest Rutherford, who proposed the nuclear model of the atom.
Db|Dubnium|268|t|u|-|1968|Named after Dubna, Russia, home of the laboratory where it was made.
Sg|Seaborgium|269|t|u|-|1974|Named after Glenn Seaborg while he was still alive.
Bh|Bohrium|270|t|u|-|1981|Named after physicist Niels Bohr.
Hs|Hassium|277|t|u|-|1984|Named after Hesse, the German state where it was first made.
Mt|Meitnerium|278|t|u|-|1982|Named after physicist Lise Meitner.
Ds|Darmstadtium|281|t|u|-|1994|Named after Darmstadt, Germany, where it was first made.
Rg|Roentgenium|282|t|u|-|1994|Named after Wilhelm Röntgen, who discovered X-rays.
Cn|Copernicium|285|t|u|-|1996|Named after the astronomer Nicolaus Copernicus.
Nh|Nihonium|286|p|u|-|2004|The first element discovered in Asia, named after Japan (Nihon).
Fl|Flerovium|289|p|u|-|1998|Named after the Flerov Laboratory in Dubna, Russia.
Mc|Moscovium|290|p|u|-|2003|Named after the Moscow region of Russia.
Lv|Livermorium|293|p|u|-|2000|Named after Lawrence Livermore National Laboratory in California.
Ts|Tennessine|294|h|u|-|2010|Named after the US state of Tennessee.
Og|Oganesson|294|g|u|-|2002|The heaviest known element, named after physicist Yuri Oganessian."""
CAT={'n':'nonmetal','g':'noble','a':'alkali','e':'alkaline','m':'metalloid','h':'halogen','p':'post','t':'transition','l':'lanthanide','c':'actinide'}
PH={'s':'solid','l':'liquid','g':'gas','u':'unknown'}
ORDER=[(1,'s',2),(2,'s',2),(2,'p',6),(3,'s',2),(3,'p',6),(4,'s',2),(3,'d',10),(4,'p',6),(5,'s',2),(4,'d',10),(5,'p',6),(6,'s',2),(4,'f',14),(5,'d',10),(6,'p',6),(7,'s',2),(5,'f',14),(6,'d',10),(7,'p',6)]
EXC={24:{'3d':5,'4s':1},29:{'3d':10,'4s':1},41:{'4d':4,'5s':1},42:{'4d':5,'5s':1},44:{'4d':7,'5s':1},45:{'4d':8,'5s':1},46:{'4d':10,'5s':0},47:{'4d':10,'5s':1},57:{'4f':0,'5d':1},58:{'4f':1,'5d':1},64:{'4f':7,'5d':1},78:{'5d':9,'6s':1},79:{'5d':10,'6s':1},89:{'5f':0,'6d':1},90:{'5f':0,'6d':2},91:{'5f':2,'6d':1},92:{'5f':3,'6d':1},93:{'5f':4,'6d':1},96:{'5f':7,'6d':1},103:{'6d':0,'7p':1}}
def occ(z,exc=True):
    o={};r=z
    for n,l,c in ORDER:
        t=min(r,c);o[f'{n}{l}']=t;r-=t
    if exc and z in EXC: o.update(EXC[z])
    return o
LO={'s':0,'p':1,'d':2,'f':3}
def config(z):
    o=occ(z)
    core=max([g for g in (2,10,18,36,54,86) if g<z],default=0)
    sym={2:'He',10:'Ne',18:'Ar',36:'Kr',54:'Xe',86:'Rn'}
    co=occ(core,False) if core else {}
    parts=[]
    for k,v in sorted(o.items(),key=lambda kv:(int(kv[0][0]),LO[kv[0][1]])):
        v-=co.get(k,0)
        if v>0: parts.append(f'{k}{v}')
    return (f'[{sym[core]}] ' if core else '')+' '.join(parts)
def shells(z):
    o=occ(z);s=[0]*7
    for k,v in o.items(): s[int(k[0])-1]+=v
    while s and s[-1]==0: s.pop()
    return s
def pos(z,cat):
    if cat=='lanthanide': return 3+(z-57),9,None,6
    if cat=='actinide': return 3+(z-89),10,None,7
    per=1 if z<=2 else 2 if z<=10 else 3 if z<=18 else 4 if z<=36 else 5 if z<=54 else 6 if z<=86 else 7
    if z==1: g=1
    elif z==2: g=18
    elif per in (2,3): g=z-(2 if per==2 else 10) if z-(2 if per==2 else 10)<=2 else z-(0 if per==3 else -8)*1
    else: g=None
    return None
# explicit group computation
def group_of(z):
    if z==1: return 1,1
    if z==2: return 18,1
    if 3<=z<=4: return z-2,2
    if 5<=z<=10: return z+8,2
    if 11<=z<=12: return z-10,3
    if 13<=z<=18: return z,3
    if 19<=z<=36: return z-18,4
    if 37<=z<=54: return z-36,5
    if z in (55,56): return z-54,6
    if 72<=z<=86: return z-68,6
    if z in (87,88): return z-86,7
    if 104<=z<=118: return z-100,7
    raise ValueError(z)
els=[]
for i,line in enumerate(RAW.split('\n')):
    z=i+1
    sym,name,mass,c,ph,en,disc,fact=line.split('|')
    cat=CAT[c]
    if cat=='lanthanide': col,row,grp,per=3+(z-57),9,None,6
    elif cat=='actinide': col,row,grp,per=3+(z-89),10,None,7
    else:
        grp,per=group_of(z); col,row=grp,per
    block='f' if cat in('lanthanide','actinide') else 's' if (z==2 or grp in(1,2)) else 'd' if 3<=grp<=12 else 'p'
    els.append(dict(z=z,symbol=sym,slug=sym.lower(),name=name,mass=mass,unstable=bool(z==43 or z==61 or (z>=84 and z not in(90,91,92))),category=cat,group=grp,period=per,block=block,phase=PH[ph],en=None if en=='-' else float(en),discovered=disc,fact=fact,shells=shells(z),config=config(z),col=col,row=row))
# ---- validation ----
assert len(els)==118
assert len({e['symbol'] for e in els})==118 and len({e['name'] for e in els})==118
assert len({(e['col'],e['row']) for e in els})==118,'grid collision'
for e in els:
    assert sum(e['shells'])==e['z'],e['symbol']
    assert e['fact'] and '|' not in e['fact']
exp={24:[2,8,13,1],29:[2,8,18,1],46:[2,8,18,18],78:[2,8,18,32,17,1],79:[2,8,18,32,18,1],103:[2,8,18,32,32,8,3],58:[2,8,18,19,9,2],90:[2,8,18,32,18,10,2],118:[2,8,18,32,32,18,8],26:[2,8,14,2],64:[2,8,18,25,9,2],92:[2,8,18,32,21,9,2]}
for z,s in exp.items(): assert els[z-1]['shells']==s,(z,els[z-1]['shells'])
from collections import Counter
print(Counter(e['category'] for e in els))
print(Counter(e['block'] for e in els), Counter(e['period'] for e in els))
for z in (8,24,26,46,57,78,92,103,104,118): print(z,els[z-1]['symbol'],els[z-1]['config'],els[z-1]['shells'])
ts='''// AUTO-GENERATED by scripts/generate-data.py — do not edit by hand.
// 118 elements. Atomic weights are abridged standard values; for elements with no
// stable isotopes the mass is the mass number of the longest-lived isotope (flag: unstable).
// Superheavy electron configurations (Rf–Og) are predicted. Electronegativity is the Pauling
// scale; null means unknown or not defined.

export type Category =
  | 'alkali' | 'alkaline' | 'transition' | 'post' | 'metalloid'
  | 'nonmetal' | 'halogen' | 'noble' | 'lanthanide' | 'actinide';
export type Phase = 'solid' | 'liquid' | 'gas' | 'unknown';
export type Block = 's' | 'p' | 'd' | 'f';

export interface ElementRecord {
  readonly z: number;
  readonly symbol: string;
  readonly slug: string;
  readonly name: string;
  readonly mass: string;
  readonly unstable: boolean;
  readonly category: Category;
  readonly group: number | null;
  readonly period: number;
  readonly block: Block;
  readonly phase: Phase;
  readonly en: number | null;
  readonly discovered: string;
  readonly fact: string;
  readonly shells: readonly number[];
  readonly config: string;
  readonly col: number;
  readonly row: number;
}

export const ALT_NAMES: Readonly<Record<number, string>> = { 13: 'Aluminum', 16: 'Sulphur', 55: 'Cesium' };

export const ELEMENTS: readonly ElementRecord[] = [
'''
ts+=',\n'.join('  '+json.dumps(e,ensure_ascii=False,separators=(',',':')) for e in els)+'\n];\n'
import pathlib
OUT=pathlib.Path(__file__).resolve().parent.parent/'src'/'data'/'elements.ts'
OUT.write_text(ts,encoding='utf-8')
print('written',len(ts))
